// com/wassalni/app/api/ApiService.java
package com.wassalni.app.api;

import java.util.List;
import java.util.Map;

import retrofit2.Call;
import retrofit2.http.*;

public interface ApiService {

    // ===== AUTH =====
    @POST("api/login")
    Call<Map<String, Object>> login(@Body Map<String, String> body);

    @GET("api/users/{id}/profil")
    Call<Map<String, Object>> getProfilLivreur(@Path("id") long id);

    // ===== LIVRAISONS =====
    @GET("api/livraisons")
    Call<List<Map<String, Object>>> getAllLivraisons();

    @GET("api/livraisons")
    Call<List<Map<String, Object>>> getLivraisonsControleur(
            @Query("controleurId") long controleurId);

    @GET("api/livraisons/today")
    Call<List<Map<String, Object>>> getLivraisonsToday(
            @Query("livreurId") long livreurId);

    @GET("api/livraisons/periode")
    Call<List<Map<String, Object>>> getLivraisonsPeriode(
            @Query("debut") String debut,
            @Query("fin") String fin);

    @GET("api/livraisons/{id}")
    Call<Map<String, Object>> getLivraison(@Path("id") long id);

    @GET("api/livraisons/{id}/detail")
    Call<Map<String, Object>> getDetailLivraison(@Path("id") long id);

    // Endpoint sync SQLite — détails complets
    @GET("api/livraisons/livreur/{id}/details")
    Call<List<Map<String, Object>>> getDetailLivraisonsLivreur(@Path("id") long livreurId);

    @PUT("api/livraisons/{id}/etat")
    Call<Map<String, Object>> updateEtat(@Path("id") long id,
                                         @Body Map<String, String> body);

    // ===== MESSAGES =====
    @GET("api/messages/conversation")
    Call<List<Map<String, Object>>> getConversation(
            @Query("user1") long user1,
            @Query("user2") long user2);

    @GET("api/messages/nonlus")
    Call<List<Map<String, Object>>> getNonLus(@Query("userId") long userId);

    @POST("api/messages/envoyer")
    Call<Map<String, Object>> envoyerMessage(@Body Map<String, Object> body);

    @PUT("api/messages/{id}/lu")
    Call<Void> marquerLu(@Path("id") long id);

    @PUT("api/messages/lireTout")
    Call<Void> marquerConversationLue(
            @Query("userId") long userId,
            @Query("expediteurId") long expediteurId);

    @GET("api/messages/livreurs")
    Call<List<Map<String, Object>>> getLivreursDisponibles(
            @Query("controleurId") long controleurId);

    @GET("api/livraisons/stats")
    Call<List<Map<String, Object>>> getAllLivraisonsStats();
}
