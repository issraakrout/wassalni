// com/wassalni/app/AccueilControleurActivity.java
package com.wassalni.app;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.wassalni.app.api.RetrofitClient;

import java.util.List;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AccueilControleurActivity extends AppCompatActivity {

    private TextView tvBonjour, tvDate, tvTotal, tvLivrees, tvEnCours, tvEchec;
    private LinearLayout menuLivraisons, menuRechercher, menuStats, menuMessagerie;
    private LinearLayout navLivraisons, navStats, navMessages;
    private CardView btnLogout, btnNotifications;

    private String prenom = "";
    private long idpers = 0;
    private int nbEchecs = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_accueil_controleur);

        // Récupérer les infos du login
        prenom = getIntent().getStringExtra("prenom");
        idpers = getIntent().getLongExtra("idpers", 0);

        // Initialiser les vues
        tvBonjour    = findViewById(R.id.tvBonjour);
        tvDate       = findViewById(R.id.tvDate);
        tvTotal      = findViewById(R.id.tvTotal);
        tvLivrees    = findViewById(R.id.tvLivrees);
        tvEnCours    = findViewById(R.id.tvEnCours);
        tvEchec      = findViewById(R.id.tvEchec);
        btnLogout    = findViewById(R.id.btnLogout);
        btnNotifications = findViewById(R.id.btnNotifications);

        menuLivraisons  = findViewById(R.id.menuLivraisons);
        menuRechercher  = findViewById(R.id.menuRechercher);
        menuStats       = findViewById(R.id.menuStats);
        menuMessagerie  = findViewById(R.id.menuMessagerie);

        navLivraisons   = findViewById(R.id.navLivraisons);
        navStats        = findViewById(R.id.navStats);
        navMessages     = findViewById(R.id.navMessages);

        // Afficher le nom
        tvBonjour.setText("Bonjour, " + prenom + " 👋");

        // Afficher la date du jour
        java.text.SimpleDateFormat sdf =
                new java.text.SimpleDateFormat("EEEE dd MMMM yyyy",
                        new java.util.Locale("fr", "FR"));
        String dateStr = sdf.format(new java.util.Date());
        tvDate.setText(dateStr.substring(0,1).toUpperCase() + dateStr.substring(1));

        // Charger les stats depuis l'API
        chargerStats();

        // Action Notifications
        btnNotifications.setOnClickListener(v -> afficherAlertes());

        // Navigation menu
        menuLivraisons.setOnClickListener(v -> {
            Intent intent = new Intent(this, ListeLivraisonsActivity.class);
            intent.putExtra("prenom", prenom);
            intent.putExtra("idpers", idpers);
            startActivity(intent);
        });

        menuRechercher.setOnClickListener(v -> {
            Intent intent = new Intent(this, ListeLivraisonsActivity.class);
            intent.putExtra("prenom", prenom);
            intent.putExtra("idpers", idpers);
            startActivity(intent);
        });

        menuStats.setOnClickListener(v -> {
            Intent intent = new Intent(this, StatistiquesActivity.class);
            intent.putExtra("prenom", prenom);
            intent.putExtra("idpers", idpers);
            startActivity(intent);
        });

        menuMessagerie.setOnClickListener(v -> {
            Intent intent = new Intent(this, ListeLivreursChatActivity.class);
            intent.putExtra("prenom", prenom);
            intent.putExtra("idpers", idpers);
            intent.putExtra("role", "CTRL");
            startActivity(intent);
        });

        // Déconnexion
        btnLogout.setOnClickListener(v -> {
            Toast.makeText(this, "Déconnexion réussie", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(this, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        });

        // Bottom nav
        navLivraisons.setOnClickListener(v -> {
            Intent intent = new Intent(this, ListeLivraisonsActivity.class);
            intent.putExtra("prenom", prenom);
            intent.putExtra("idpers", idpers);
            startActivity(intent);
        });

        navStats.setOnClickListener(v -> {
            Intent intent = new Intent(this, StatistiquesActivity.class);
            intent.putExtra("prenom", prenom);
            intent.putExtra("idpers", idpers);
            startActivity(intent);
        });

        navMessages.setOnClickListener(v -> {
            Intent intent = new Intent(this, ListeLivreursChatActivity.class);
            intent.putExtra("prenom", prenom);
            intent.putExtra("idpers", idpers);
            intent.putExtra("role", "CTRL");
            startActivity(intent);
        });
    }

    private void afficherAlertes() {
        String message = (nbEchecs > 0) ? 
                "Il y a actuellement " + nbEchecs + " livraison(s) en échec nécessitant votre attention." :
                "Aucune alerte critique pour le moment. Toutes les livraisons se passent bien !";
        
        new AlertDialog.Builder(this)
                .setTitle("Alertes du jour")
                .setMessage(message)
                .setPositiveButton("Voir les détails", (dialog, which) -> {
                    Intent intent = new Intent(this, ListeLivraisonsActivity.class);
                    intent.putExtra("filtre", "Echec");
                    startActivity(intent);
                })
                .setNegativeButton("Fermer", null)
                .setIcon(android.R.drawable.ic_dialog_info)
                .show();
    }

    private void chargerStats() {
        RetrofitClient.getService().getAllLivraisons()
                .enqueue(new Callback<List<Map<String, Object>>>() {

                    @Override
                    public void onResponse(Call<List<Map<String, Object>>> call,
                                           Response<List<Map<String, Object>>> response) {
                        if (response.isSuccessful() && response.body() != null) {
                            List<Map<String, Object>> livraisons = response.body();

                            int total    = livraisons.size();
                            int livrees  = 0;
                            int enCours  = 0;
                            int echec    = 0;

                            for (Map<String, Object> liv : livraisons) {
                                String etat = (String) liv.get("etatliv");
                                if ("Livrée".equalsIgnoreCase(etat))      livrees++;
                                else if ("En cours".equalsIgnoreCase(etat)) enCours++;
                                else if ("Échec".equalsIgnoreCase(etat) || "Non livrée".equalsIgnoreCase(etat)) echec++;
                            }

                            nbEchecs = echec;
                            tvTotal.setText(String.valueOf(total));
                            tvLivrees.setText(String.valueOf(livrees));
                            tvEnCours.setText(String.valueOf(enCours));
                            tvEchec.setText(String.valueOf(echec));
                        }
                    }

                    @Override
                    public void onFailure(Call<List<Map<String, Object>>> call, Throwable t) {
                    }
                });
    }
}
