// com/wassalni/app/AccueilLivreurActivity.java
package com.wassalni.app;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.wassalni.app.adapter.LivraisonLivreurAdapter;
import com.wassalni.app.database.LivraisonLocale;
import com.wassalni.app.database.SyncManager;
import com.wassalni.app.database.WassalniDatabase;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class AccueilLivreurActivity extends AppCompatActivity {

    private TextView tvBonjour, tvDate, tvTotal, tvLivrees, tvRestantes;
    private TextView tvProgression, tvPourcentage, tvSyncStatus;
    private ProgressBar progressBar;
    private RecyclerView recyclerView;
    private LivraisonLivreurAdapter adapter;

    private String prenom;
    private long idpers;
    private List<Map<String, Object>> livraisons = new ArrayList<>();
    private SyncManager syncManager;
    private ExecutorService executor = Executors.newSingleThreadExecutor();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_accueil_livreur);

        prenom = getIntent().getStringExtra("prenom");
        idpers = getIntent().getLongExtra("idpers", 0);

        tvBonjour     = findViewById(R.id.tvBonjour);
        tvDate        = findViewById(R.id.tvDate);
        tvTotal       = findViewById(R.id.tvTotal);
        tvLivrees     = findViewById(R.id.tvLivrees);
        tvRestantes   = findViewById(R.id.tvRestantes);
        tvProgression = findViewById(R.id.tvProgression);
        tvPourcentage = findViewById(R.id.tvPourcentage);
        progressBar   = findViewById(R.id.progressBar);
        recyclerView  = findViewById(R.id.recyclerLivraisons);
        tvSyncStatus  = findViewById(R.id.tvSyncStatus);

        tvBonjour.setText("Bonjour, " + prenom + " 🚀");

        SimpleDateFormat sdf =
                new SimpleDateFormat("dd MMMM yyyy",
                        new Locale("fr", "FR"));
        tvDate.setText(sdf.format(new Date()));

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new LivraisonLivreurAdapter(this, livraisons, liv -> {
            long nocde = ((Double) liv.get("nocde")).longValue();
            Intent intent = new Intent(this, DetailCommandeLivreurActivity.class);
            intent.putExtra("nocde",   nocde);
            intent.putExtra("prenom",  prenom);
            intent.putExtra("idpers",  idpers);
            startActivity(intent);
        });
        recyclerView.setAdapter(adapter);

        syncManager = new SyncManager(this, idpers);
        lancerSync();



        findViewById(R.id.navMessages).setOnClickListener(v -> {
            Intent intent = new Intent(this, MessagerieActivity.class);
            intent.putExtra("prenom",        prenom);
            intent.putExtra("idpers",        idpers);
            intent.putExtra("role",          "LIV");
            intent.putExtra("interlocuteur", 1L);
            startActivity(intent);
        });

        findViewById(R.id.navProfil).setOnClickListener(v -> {
            Intent intent = new Intent(this, ProfilLivreurActivity.class);
            intent.putExtra("idpers", idpers);
            startActivity(intent);
        });
    }

    private void lancerSync() {
        if (tvSyncStatus != null) {
            tvSyncStatus.setVisibility(View.VISIBLE);
            tvSyncStatus.setText("🔄 Synchronisation...");
            tvSyncStatus.setTextColor(Color.parseColor("#F39C12"));
        }

        syncManager.verifierEtSynchroniser(new SyncManager.SyncCallback() {
            @Override
            public void onSuccess(int nb) {
                runOnUiThread(() -> {
                    if (tvSyncStatus != null) {
                        tvSyncStatus.setText("✓ " + nb + " livraisons synchronisées");
                        tvSyncStatus.setTextColor(Color.parseColor("#2ECC71"));
                    }
                });
                chargerDepuisSQLite();
                syncManager.syncModificationsOffline();
            }

            @Override
            public void onError(String msg) {
                runOnUiThread(() -> {
                    if (tvSyncStatus != null) {
                        tvSyncStatus.setText("⚠ Hors ligne — données locales");
                        tvSyncStatus.setTextColor(Color.parseColor("#E74C3C"));
                    }
                });
                chargerDepuisSQLite();
            }
        });
    }

    private void synchroniserDepuisApi() {
        if (tvSyncStatus != null) {
            tvSyncStatus.setVisibility(View.VISIBLE);
            tvSyncStatus.setText("🔄 Synchronisation...");
            tvSyncStatus.setTextColor(Color.parseColor("#F39C12"));
        }
        syncManager.synchroniser(new SyncManager.SyncCallback() {
            @Override
            public void onSuccess(int nb) {
                if (tvSyncStatus != null) {
                    tvSyncStatus.setText("✓ " + nb + " livraisons synchronisées");
                    tvSyncStatus.setTextColor(Color.parseColor("#2ECC71"));
                }
                chargerDepuisSQLite();
                syncManager.syncModificationsOffline();
            }
            @Override
            public void onError(String msg) {
                if (tvSyncStatus != null) {
                    tvSyncStatus.setText("⚠ Hors ligne — données locales");
                    tvSyncStatus.setTextColor(Color.parseColor("#E74C3C"));
                }
                chargerDepuisSQLite();
            }
        });
    }

    private void chargerDepuisSQLite() {
        executor.execute(() -> {
            WassalniDatabase db = WassalniDatabase.getInstance(this);
            List<LivraisonLocale> locales = db.livraisonDao().getToutesLivraisons();

            List<Map<String, Object>> liste = new ArrayList<>();
            for (LivraisonLocale l : locales) {
                Map<String, Object> map = new HashMap<>();
                map.put("nocde",        (double) l.nocde);
                map.put("etatliv",      l.etatliv);
                map.put("modepay",      l.modepay);
                map.put("dateliv",      l.dateliv);
                map.put("nomClient",    l.nomClient);
                map.put("prenomClient", l.prenomClient);
                map.put("telClient",    l.telClient);
                map.put("villeClient",  l.villeClient);
                map.put("montantTotal", l.montantTotal);
                liste.add(map);
            }

            runOnUiThread(() -> {
                livraisons.clear();
                livraisons.addAll(liste);
                adapter.notifyDataSetChanged();
                mettreAJourStats(locales);
            });
        });
    }

    private void mettreAJourStats(List<LivraisonLocale> locales) {
        int total   = locales.size();
        int livrees = 0;
        for (LivraisonLocale l : locales)
            if ("Livrée".equals(l.etatliv)) livrees++;
        int restantes = total - livrees;
        int pct = total > 0 ? (livrees * 100 / total) : 0;

        tvTotal.setText(String.valueOf(total));
        tvLivrees.setText(String.valueOf(livrees));
        tvRestantes.setText(String.valueOf(restantes));
        tvProgression.setText("Progression : " + livrees + " / " + total);
        tvPourcentage.setText(pct + " %");
        progressBar.setProgress(pct);
    }

    @Override

    protected void onResume() {
        super.onResume();
        // ✅ Charger depuis SQLite uniquement, sans relancer la sync
        chargerDepuisSQLite();
    }
}
