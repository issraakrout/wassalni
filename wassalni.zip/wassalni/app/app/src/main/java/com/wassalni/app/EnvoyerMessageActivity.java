// com/wassalni/app/EnvoyerMessageActivity.java
package com.wassalni.app;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.wassalni.app.api.RetrofitClient;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class EnvoyerMessageActivity extends AppCompatActivity {

    // Livreurs disponibles (chargés depuis l'API)
    private List<Map<String, Object>> livreurs = new ArrayList<>();
    private String destinataireSelectionne = null; // null = "Tous"

    private TextView tvSpinnerNom;
    private LinearLayout containerPills;
    private EditText etMessage;
    private TextView tvCompteur;
    private RadioButton rbInfoGeneral, rbUrgent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_envoyer_message);

        // Bind vues
        tvSpinnerNom   = findViewById(R.id.tvSpinnerNom);
        containerPills = findViewById(R.id.containerPills);
        etMessage      = findViewById(R.id.etMessage);
        tvCompteur     = findViewById(R.id.tvCompteur);
        rbInfoGeneral  = findViewById(R.id.rbInfoGeneral);
        rbUrgent       = findViewById(R.id.rbUrgent);

        // Bouton retour
        findViewById(R.id.btnBack).setOnClickListener(v -> finish());

        // Compteur de caractères
        etMessage.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                tvCompteur.setText(s.length() + "/250");
            }
            @Override public void afterTextChanged(Editable s) {}
        });

        // Bouton envoyer
        findViewById(R.id.btnEnvoyer).setOnClickListener(v -> envoyerMessage());

        // Charger les livreurs
        chargerLivreurs();
    }

    private void chargerLivreurs() {
        // On récupère les livreurs depuis /api/livraisons pour en extraire les noms uniques
        RetrofitClient.getService().getAllLivraisons()
                .enqueue(new Callback<List<Map<String, Object>>>() {
                    @Override
                    public void onResponse(Call<List<Map<String, Object>>> call,
                                           Response<List<Map<String, Object>>> response) {
                        if (response.isSuccessful() && response.body() != null) {
                            // Extraire les livreurs uniques
                            Map<Long, Map<String, Object>> livreursMap = new HashMap<>();
                            for (Map<String, Object> liv : response.body()) {
                                Object idObj = liv.get("livreur");
                                if (idObj != null) {
                                    long id = ((Number) idObj).longValue();
                                    if (!livreursMap.containsKey(id)) {
                                        Map<String, Object> info = new HashMap<>();
                                        info.put("id", id);
                                        info.put("nom",    liv.get("nomLivreur"));
                                        info.put("prenom", liv.get("prenomLivreur"));
                                        livreursMap.put(id, info);
                                    }
                                }
                            }
                            livreurs.clear();
                            livreurs.addAll(livreursMap.values());
                            afficherPills();
                        }
                    }
                    @Override
                    public void onFailure(Call<List<Map<String, Object>>> call, Throwable t) {
                        // Mode offline : on affiche quand même "Tous"
                        afficherPills();
                    }
                });
    }

    private void afficherPills() {
        containerPills.removeAllViews();

        // Pill "Tous"
        ajouterPill("Tous", null);

        // Pills par livreur
        for (Map<String, Object> liv : livreurs) {
            String prenom = (String) liv.get("prenom");
            String nom    = (String) liv.get("nom");
            String label  = (prenom != null ? prenom.substring(0, Math.min(prenom.length(), 1)) + ". " : "")
                    + (nom != null ? nom : "");
            String fullName = (prenom != null ? prenom : "") + " " + (nom != null ? nom : "");
            ajouterPill(label.trim(), fullName.trim());
        }

        // Sélectionner "Tous" par défaut
        selectionnerDestinataire(null);
    }

    private void ajouterPill(String label, String fullName) {
        TextView pill = new TextView(this);
        pill.setText(label);
        pill.setTextSize(13f);
        pill.setPadding(24, 8, 24, 8);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 0, 8, 0);
        pill.setLayoutParams(lp);

        // Tag pour identifier
        pill.setTag(fullName);

        // Style initial
        pill.setBackground(getDrawable(R.drawable.bg_pill_unselected));
        pill.setTextColor(0xFF555555);

        pill.setOnClickListener(v -> selectionnerDestinataire(fullName));
        containerPills.addView(pill);
    }

    private void selectionnerDestinataire(String fullName) {
        destinataireSelectionne = fullName;

        // Mettre à jour spinner
        if (fullName == null) {
            tvSpinnerNom.setText("Tous les livreurs");
        } else {
            tvSpinnerNom.setText(fullName);
        }

        // Mettre à jour les pills
        for (int i = 0; i < containerPills.getChildCount(); i++) {
            View child = containerPills.getChildAt(i);
            if (child instanceof TextView) {
                TextView pill = (TextView) child;
                String tag = (String) pill.getTag();
                boolean selected = (fullName == null && tag == null)
                        || (fullName != null && fullName.equals(tag));
                if (selected) {
                    pill.setBackground(getDrawable(R.drawable.bg_pill_selected));
                    pill.setTextColor(0xFFFFFFFF);
                } else {
                    pill.setBackground(getDrawable(R.drawable.bg_pill_unselected));
                    pill.setTextColor(0xFF555555);
                }
            }
        }
    }

    private void envoyerMessage() {
        String texte = etMessage.getText().toString().trim();
        if (texte.isEmpty()) {
            Toast.makeText(this, "Veuillez saisir un message.", Toast.LENGTH_SHORT).show();
            return;
        }
        String type = rbUrgent.isChecked() ? "Urgent" : "Information générale";
        String dest = destinataireSelectionne != null ? destinataireSelectionne : "Tous les livreurs";

        // TODO : Appel API réel pour envoyer le message
        // Pour l'instant on simule l'envoi
        Toast.makeText(this,
                "✓ Message envoyé à " + dest + " (" + type + ")",
                Toast.LENGTH_LONG).show();
        etMessage.setText("");
        finish();
    }
}