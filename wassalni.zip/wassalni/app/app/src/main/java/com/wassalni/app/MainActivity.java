// com/wassalni/app/MainActivity.java
package com.wassalni.app;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.wassalni.app.api.ApiService;
import com.wassalni.app.api.RetrofitClient;

import java.util.HashMap;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    // Widgets
    private LinearLayout btnControleur, btnLivreur;
    private Button btnLogin;
    private EditText etLogin, etPassword;
    private TextView tvError;

    // Rôle sélectionné
    private String roleSelectionne = "CTRL";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialiser les widgets
        btnControleur = (LinearLayout) findViewById(R.id.btnControleur);
        btnLivreur    = (LinearLayout) findViewById(R.id.btnLivreur);
        btnLogin      = (Button)       findViewById(R.id.btnLogin);
        etLogin       = (EditText)     findViewById(R.id.etLogin);
        etPassword    = (EditText)     findViewById(R.id.etPassword);
        tvError       = (TextView)     findViewById(R.id.tvError);

        // Contrôleur sélectionné par défaut
        selectControleur();

        // Clic sur Contrôleur
        btnControleur.setOnClickListener(v -> selectControleur());

        // Clic sur Livreur
        btnLivreur.setOnClickListener(v -> selectLivreur());

        // Bouton Se connecter
        btnLogin.setOnClickListener(v -> seConnecter());
    }

    private void selectControleur() {
        roleSelectionne = "CTRL";
        btnControleur.setBackgroundResource(R.drawable.bg_role_selected);
        btnLivreur.setBackgroundResource(R.drawable.bg_role_unselected);
        // Changer couleur texte
        ((TextView) btnControleur.getChildAt(1)).setTextColor(
                getResources().getColor(android.R.color.holo_blue_dark));
        ((TextView) btnLivreur.getChildAt(1)).setTextColor(
                getResources().getColor(android.R.color.darker_gray));
    }

    private void selectLivreur() {
        roleSelectionne = "LIV";
        btnLivreur.setBackgroundResource(R.drawable.bg_role_selected);
        btnControleur.setBackgroundResource(R.drawable.bg_role_unselected);
        // Changer couleur texte
        ((TextView) btnLivreur.getChildAt(1)).setTextColor(
                getResources().getColor(android.R.color.holo_green_dark));
        ((TextView) btnControleur.getChildAt(1)).setTextColor(
                getResources().getColor(android.R.color.darker_gray));
    }

    private void seConnecter() {
        String login = etLogin.getText().toString().trim();
        String motP  = etPassword.getText().toString().trim();

        // Validation
        if (login.isEmpty()) {
            etLogin.setError("Veuillez entrer votre login");
            return;
        }
        if (motP.isEmpty()) {
            etPassword.setError("Veuillez entrer votre mot de passe");
            return;
        }

        // Désactiver le bouton pendant la requête
        btnLogin.setEnabled(false);
        btnLogin.setText("Connexion...");
        tvError.setVisibility(View.GONE);

        // Appel API
        ApiService api = RetrofitClient.getService();
        Map<String, String> body = new HashMap<>();
        body.put("login", login);
        body.put("motP", motP);

        api.login(body).enqueue(new Callback<Map<String, Object>>() {

            @Override
            public void onResponse(Call<Map<String, Object>> call,
                                   Response<Map<String, Object>> response) {
                btnLogin.setEnabled(true);
                btnLogin.setText("Se connecter");

                if (response.isSuccessful() && response.body() != null) {
                    Map<String, Object> data = response.body();
                    boolean success = Boolean.TRUE.equals(data.get("success"));

                    if (success) {
                        String role   = (String) data.get("role");
                        String nom    = (String) data.get("nom");
                        String prenom = (String) data.get("prenom");
                        double idpers = (double) data.get("idpers");

                        Toast.makeText(MainActivity.this,
                                "Bienvenue " + prenom + " !", Toast.LENGTH_SHORT).show();

                        // Rediriger selon le rôle
                        Intent intent;
                        if ("CTRL".equals(role)) {
                            intent = new Intent(MainActivity.this,
                                    AccueilControleurActivity.class);
                        } else {
                            intent = new Intent(MainActivity.this,
                                    AccueilLivreurActivity.class);
                        }
                        intent.putExtra("nom",    nom);
                        intent.putExtra("prenom", prenom);
                        intent.putExtra("idpers", (long) idpers);
                        startActivity(intent);
                        finish();

                    } else {
                        tvError.setText("Login ou mot de passe incorrect");
                        tvError.setVisibility(View.VISIBLE);
                    }
                } else {
                    tvError.setText("Erreur serveur. Réessayez.");
                    tvError.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void onFailure(Call<Map<String, Object>> call, Throwable t) {
                btnLogin.setEnabled(true);
                btnLogin.setText("Se connecter");
                tvError.setText("Impossible de joindre le serveur.\nVérifiez votre connexion.");
                tvError.setVisibility(View.VISIBLE);
            }
        });
    }
}