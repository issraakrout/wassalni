// com/wassalni/app/DetailLivraisonActivity.java
package com.wassalni.app;

import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.wassalni.app.api.RetrofitClient;

import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DetailLivraisonActivity extends AppCompatActivity {

    private TextView tvTitreCommande, tvBadgeEtat;
    private TextView tvAvatarClient, tvNomClient, tvTelClient, tvAdresseClient;
    private TextView tvAvatarLivreur, tvNomLivreur, tvTelLivreur;
    private TextView tvDetailNoCde, tvDateCommande, tvDateLivraison;
    private TextView tvMontant, tvPaiement, tvEtatDetail;

    private long nocde;
    private String prenom;
    private long idpers;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_livraison);

        // Récupérer les données passées
        nocde  = getIntent().getLongExtra("nocde", 0);
        prenom = getIntent().getStringExtra("prenom");
        idpers = getIntent().getLongExtra("idpers", 0);

        // Initialiser les vues
        tvTitreCommande  = findViewById(R.id.tvTitreCommande);
        tvBadgeEtat      = findViewById(R.id.tvBadgeEtat);
        tvAvatarClient   = findViewById(R.id.tvAvatarClient);
        tvNomClient      = findViewById(R.id.tvNomClient);
        tvTelClient      = findViewById(R.id.tvTelClient);
        tvAdresseClient  = findViewById(R.id.tvAdresseClient);
        tvAvatarLivreur  = findViewById(R.id.tvAvatarLivreur);
        tvNomLivreur     = findViewById(R.id.tvNomLivreur);
        tvTelLivreur     = findViewById(R.id.tvTelLivreur);
        tvDetailNoCde    = findViewById(R.id.tvDetailNoCde);
        tvDateCommande   = findViewById(R.id.tvDateCommande);
        tvDateLivraison  = findViewById(R.id.tvDateLivraison);
        tvMontant        = findViewById(R.id.tvMontant);
        tvPaiement       = findViewById(R.id.tvPaiement);
        tvEtatDetail     = findViewById(R.id.tvEtatDetail);

        // Bouton retour
        ((ImageView) findViewById(R.id.btnRetour)).setOnClickListener(v -> finish());

        // Titre
        tvTitreCommande.setText("#" + nocde);

        // Charger les détails depuis l'API
        chargerDetail();

        // Bottom nav
        findViewById(R.id.navAccueil).setOnClickListener(v -> {
            Intent intent = new Intent(this, AccueilControleurActivity.class);
            intent.putExtra("prenom", prenom);
            intent.putExtra("idpers", idpers);
            startActivity(intent);
            finish();
        });
        findViewById(R.id.navLivraisons).setOnClickListener(v -> finish());
        findViewById(R.id.navStats).setOnClickListener(v ->
                Toast.makeText(this, "Stats — bientôt", Toast.LENGTH_SHORT).show());
        findViewById(R.id.navMessages).setOnClickListener(v ->
                Toast.makeText(this, "Messages — bientôt", Toast.LENGTH_SHORT).show());
    }

    private void chargerDetail() {
        RetrofitClient.getService().getDetailLivraison(nocde)
                .enqueue(new Callback<Map<String, Object>>() {

                    @Override
                    public void onResponse(Call<Map<String, Object>> call,
                                           Response<Map<String, Object>> response) {
                        if (response.isSuccessful() && response.body() != null) {
                            Map<String, Object> data = response.body();
                            afficherDetail(data);
                        }
                    }

                    @Override
                    public void onFailure(Call<Map<String, Object>> call, Throwable t) {
                        Toast.makeText(DetailLivraisonActivity.this,
                                "Erreur de connexion", Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void afficherDetail(Map<String, Object> d) {

        // ---- CLIENT ----
        String nomClt    = getString(d, "nomClient") + " " + getString(d, "prenomClient");
        String telClt    = getString(d, "telClient");
        String adrClt    = getString(d, "adresseClient") + ", " + getString(d, "villeClient");
        String initiales = getInitiales(nomClt);

        tvAvatarClient.setText(initiales);
        tvNomClient.setText(nomClt);
        tvTelClient.setText(telClt);
        tvAdresseClient.setText(adrClt);
        
        // Rendre le numéro cliquable pour appeler
        if (telClt != null && !telClt.equals("—")) {
            initAppel(tvTelClient, telClt);
        }

        // ---- LIVREUR ----
        String nomLiv  = getString(d, "nomLivreur") + " " + getString(d, "prenomLivreur");
        String telLiv  = getString(d, "telLivreur");
        String initLiv = getInitiales(nomLiv);

        tvAvatarLivreur.setText(initLiv);
        tvNomLivreur.setText(nomLiv);
        tvTelLivreur.setText(telLiv);

        // Rendre le numéro cliquable pour appeler
        if (telLiv != null && !telLiv.equals("—")) {
            initAppel(tvTelLivreur, telLiv);
        }

        // ---- DÉTAILS COMMANDE ----
        tvDetailNoCde.setText("#" + nocde);
        tvDateCommande.setText(getString(d, "dateCommande"));
        tvDateLivraison.setText(getString(d, "dateLivraison"));

        // Montant
        Object montantObj = d.get("montantTotal");
        String montant = montantObj != null ?
                String.format("%,.0f DT", ((Double) montantObj)) : "—";
        tvMontant.setText(montant);

        // Paiement
        tvPaiement.setText(getString(d, "modepay"));

        // État + couleur badge
        String etat = getString(d, "etatliv");
        tvBadgeEtat.setText(etat);
        tvEtatDetail.setText(etat);
        appliquerCouleurBadge(tvBadgeEtat, etat);
        appliquerCouleurBadge(tvEtatDetail, etat);
    }

    private void initAppel(View view, String telephone) {
        view.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_DIAL);
            intent.setData(Uri.parse("tel:" + telephone));
            startActivity(intent);
        });
    }

    private void appliquerCouleurBadge(TextView tv, String etat) {
        switch (etat) {
            case "Livrée":
                tv.setTextColor(Color.parseColor("#1B7A3E"));
                tv.setBackgroundResource(R.drawable.bg_badge_livree);
                break;
            case "En cours":
                tv.setTextColor(Color.parseColor("#7A4F00"));
                tv.setBackgroundResource(R.drawable.bg_badge_encours);
                break;
            case "Non livrée":
                tv.setTextColor(Color.parseColor("#7A1E1E"));
                tv.setBackgroundResource(R.drawable.bg_badge_nonlivree);
                break;
            default:
                tv.setTextColor(Color.parseColor("#555555"));
                tv.setBackgroundResource(R.drawable.bg_badge_livree);
        }
    }

    // Récupère une String depuis la Map sans NullPointerException
    private String getString(Map<String, Object> map, String key) {
        Object val = map.get(key);
        return val != null ? val.toString() : "—";
    }

    // Génère les initiales ex: "Sami Ben Ali" → "SB"
    private String getInitiales(String nom) {
        String[] parts = nom.trim().split(" ");
        if (parts.length >= 2) {
            return ("" + parts[0].charAt(0) + parts[1].charAt(0)).toUpperCase();
        } else if (parts.length == 1 && !parts[0].isEmpty()) {
            return ("" + parts[0].charAt(0)).toUpperCase();
        }
        return "?";
    }
}