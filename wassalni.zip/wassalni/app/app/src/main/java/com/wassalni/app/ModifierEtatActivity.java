package com.wassalni.app;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.wassalni.app.api.RetrofitClient;
import com.wassalni.app.database.LivraisonDao;
import com.wassalni.app.database.WassalniDatabase;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ModifierEtatActivity extends AppCompatActivity {

    private static final String TAG = "ModifierEtatActivity";

    private long nocde;
    private String currentEtat;
    private String nomClient;
    private double montantTotal;

    private RadioGroup radioGroupEtat;
    private TextView tvTitre, tvRecap;
    private EditText etRemarque;
    private Button btnModifier;
    private ImageView btnRetour;

    private LivraisonDao livraisonDao;
    private final Executor executor = Executors.newSingleThreadExecutor();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modifier_etat);

        livraisonDao = WassalniDatabase.getInstance(this).livraisonDao();

        nocde        = getIntent().getLongExtra("nocde", -1);
        currentEtat  = getIntent().getStringExtra("etat");
        nomClient    = getIntent().getStringExtra("nomClient");
        montantTotal = getIntent().getDoubleExtra("montantTotal", 0.0);

        tvTitre        = findViewById(R.id.tvTitre);
        tvRecap        = findViewById(R.id.tvRecap);
        etRemarque     = findViewById(R.id.etRemarque);
        btnModifier    = findViewById(R.id.btnConfirmer);
        btnRetour      = findViewById(R.id.btnRetour);
        radioGroupEtat = findViewById(R.id.radioGroupEtat);

        tvTitre.setText("Modifier #" + nocde);
        tvRecap.setText("#" + nocde + " · " + nomClient + " · " + String.format("%.2f DT", montantTotal));

        // ✅ Les containers cliquables sélectionnent le bon radio via RadioGroup
        findViewById(R.id.optionLivree).setOnClickListener(v -> radioGroupEtat.check(R.id.radioLivree));
        findViewById(R.id.optionEnCours).setOnClickListener(v -> radioGroupEtat.check(R.id.radioEnCours));
        findViewById(R.id.optionEnAttente).setOnClickListener(v -> radioGroupEtat.check(R.id.radioEnAttente));
        findViewById(R.id.optionNonLivree).setOnClickListener(v -> radioGroupEtat.check(R.id.radioNonLivree));
        findViewById(R.id.optionReportee).setOnClickListener(v -> radioGroupEtat.check(R.id.radioReportee));

        // ✅ Sélectionner l'état actuel une seule fois
        if (currentEtat != null) setSelectedEtat(currentEtat);

        btnModifier.setOnClickListener(v -> modifierEtatLivraison());
        btnRetour.setOnClickListener(v -> finish());
    }

    // ✅ Utilise RadioGroup.check() — pas besoin de setupRadioButtons()
    private void setSelectedEtat(String etat) {
        switch (etat) {
            case "Livrée":     radioGroupEtat.check(R.id.radioLivree);    break;
            case "En cours":   radioGroupEtat.check(R.id.radioEnCours);   break;
            case "En attente": radioGroupEtat.check(R.id.radioEnAttente); break;
            case "Échec":
            case "Non livrée": radioGroupEtat.check(R.id.radioNonLivree); break;
            case "Reportée":   radioGroupEtat.check(R.id.radioReportee);  break;
        }
    }

    // ✅ Utilise RadioGroup.getCheckedRadioButtonId()
    private String getSelectedEtat() {
        int checkedId = radioGroupEtat.getCheckedRadioButtonId();
        if (checkedId == R.id.radioLivree)    return "Livrée";
        if (checkedId == R.id.radioEnCours)   return "En cours";
        if (checkedId == R.id.radioEnAttente) return "En attente";
        if (checkedId == R.id.radioNonLivree) return "Échec";
        if (checkedId == R.id.radioReportee)  return "Reportée";
        return currentEtat;
    }

    private void modifierEtatLivraison() {
        String nouvelEtat = getSelectedEtat();
        String remarque   = etRemarque.getText().toString().trim();

        if ((nouvelEtat.equals("Échec") || nouvelEtat.equals("Reportée")) && remarque.isEmpty()) {
            etRemarque.setError("Veuillez ajouter une remarque pour cet état.");
            etRemarque.requestFocus();
            return;
        }

        executor.execute(() -> {
            // ✅ 1. Sauvegarder localement avec modifieLocalement = 1
            livraisonDao.mettreAJourEtat(nocde, nouvelEtat, remarque);
            Log.d(TAG, "État sauvegardé localement: " + nouvelEtat);

            Map<String, String> body = new HashMap<>();
            body.put("etatliv", nouvelEtat);
            body.put("remarque", remarque);

            RetrofitClient.getService().updateEtat(nocde, body)
                    .enqueue(new Callback<Map<String, Object>>() {

                        @Override
                        public void onResponse(Call<Map<String, Object>> call,
                                               Response<Map<String, Object>> response) {
                            if (response.isSuccessful() && response.body() != null) {

                                // ✅ 2. Vérifier que le serveur retourne bien le bon état
                                Map<String, Object> serverData = response.body();
                                Object serverEtat = serverData.get("etatliv");

                                if (serverEtat != null && serverEtat.toString().equals(nouvelEtat)) {
                                    // ✅ 3. Serveur confirmé → marquer synchronisé
                                    executor.execute(() -> {
                                        livraisonDao.marquerSynchronise(nocde);
                                        mainHandler.post(() -> {
                                            Toast.makeText(ModifierEtatActivity.this,
                                                    "✅ État mis à jour et synchronisé !", Toast.LENGTH_SHORT).show();
                                            setResult(RESULT_OK);
                                            finish();
                                        });
                                    });
                                } else {
                                    // ⚠ Serveur a répondu mais pas le bon état
                                    mainHandler.post(() -> {
                                        Toast.makeText(ModifierEtatActivity.this,
                                                "⚠ Sauvegardé localement. Sera synchronisé plus tard.",
                                                Toast.LENGTH_LONG).show();
                                        setResult(RESULT_OK);
                                        finish();
                                    });
                                }

                            } else {
                                mainHandler.post(() -> {
                                    Toast.makeText(ModifierEtatActivity.this,
                                            "⚠ Sauvegardé localement. Sera synchronisé plus tard.",
                                            Toast.LENGTH_LONG).show();
                                    setResult(RESULT_OK);
                                    finish();
                                });
                            }
                        }

                        @Override
                        public void onFailure(Call<Map<String, Object>> call, Throwable t) {
                            mainHandler.post(() -> {
                                Toast.makeText(ModifierEtatActivity.this,
                                        "📴 Sauvegardé localement. Sera synchronisé quand vous serez en ligne.",
                                        Toast.LENGTH_LONG).show();
                                setResult(RESULT_OK);
                                finish();
                            });
                        }
                    });
        });
    }
}