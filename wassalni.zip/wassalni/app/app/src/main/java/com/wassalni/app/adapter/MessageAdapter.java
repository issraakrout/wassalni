package com.wassalni.app.adapter;

import android.content.Context;
import android.graphics.Color;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.wassalni.app.R;
import com.wassalni.app.model.Message;

import java.util.List;

public class MessageAdapter extends RecyclerView.Adapter<MessageAdapter.ViewHolder> {

    private List<Message> messages;
    private long currentUserId;
    private Context context;

    public MessageAdapter(Context context, List<Message> messages, long currentUserId) {
        this.context = context;
        this.messages = messages;
        this.currentUserId = currentUserId;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_message, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Message msg = messages.get(position);
        holder.tvContenu.setText(msg.getContenu());
        
        // Formater l'heure (extraire de 2026-04-22 10:24:00)
        String heure = msg.getHeureenvoi();
        if (heure != null && heure.length() >= 16) {
            holder.tvHeure.setText(heure.substring(11, 16));
        } else {
            holder.tvHeure.setText("");
        }

        LinearLayout.LayoutParams params = (LinearLayout.LayoutParams) holder.container.getLayoutParams();

        if (msg.getExpediteur() == currentUserId) {
            // Message envoyé (Moi)
            holder.container.setGravity(Gravity.END);
            holder.tvContenu.setBackgroundResource(R.drawable.bg_bubble_envoye);
            holder.tvContenu.setTextColor(Color.WHITE);
            holder.tvExpediteur.setVisibility(View.GONE);
        } else {
            // Message reçu
            holder.container.setGravity(Gravity.START);
            holder.tvContenu.setBackgroundResource(R.drawable.bg_bubble_recu);
            holder.tvContenu.setTextColor(Color.BLACK);
            // holder.tvExpediteur.setVisibility(View.VISIBLE);
        }

        // Si c'est urgent
        if ("Urgent".equalsIgnoreCase(msg.getTypeMsg())) {
            holder.tvContenu.setBackgroundResource(R.drawable.bg_bubble_urgent);
            holder.tvContenu.setTextColor(Color.WHITE);
        }
    }

    @Override
    public int getItemCount() {
        return messages.size();
    }

    public void updateData(List<Message> newMessages) {
        this.messages = newMessages;
        notifyDataSetChanged();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvExpediteur, tvContenu, tvHeure;
        LinearLayout container;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvExpediteur = itemView.findViewById(R.id.tvExpediteur);
            tvContenu = itemView.findViewById(R.id.tvContenu);
            tvHeure = itemView.findViewById(R.id.tvHeure);
            container = (LinearLayout) itemView;
        }
    }
}
