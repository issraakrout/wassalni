package com.wassalni.app.model;

public class Message {
    private long idmsg;
    private long expediteur;
    private long destinataire;
    private String contenu;
    private String heureenvoi;
    private String typeMsg;
    private Long nocde;
    private int lu;

    public Message() {}

    public Message(long expediteur, long destinataire, String contenu, String typeMsg, Long nocde) {
        this.expediteur = expediteur;
        this.destinataire = destinataire;
        this.contenu = contenu;
        this.typeMsg = typeMsg;
        this.nocde = nocde;
    }

    public long getIdmsg() { return idmsg; }
    public void setIdmsg(long idmsg) { this.idmsg = idmsg; }

    public long getExpediteur() { return expediteur; }
    public void setExpediteur(long expediteur) { this.expediteur = expediteur; }

    public long getDestinataire() { return destinataire; }
    public void setDestinataire(long destinataire) { this.destinataire = destinataire; }

    public String getContenu() { return contenu; }
    public void setContenu(String contenu) { this.contenu = contenu; }

    public String getHeureenvoi() { return heureenvoi; }
    public void setHeureenvoi(String heureenvoi) { this.heureenvoi = heureenvoi; }

    public String getTypeMsg() { return typeMsg; }
    public void setTypeMsg(String typeMsg) { this.typeMsg = typeMsg; }

    public Long getNocde() { return nocde; }
    public void setNocde(Long nocde) { this.nocde = nocde; }

    public int getLu() { return lu; }
    public void setLu(int lu) { this.lu = lu; }
}
