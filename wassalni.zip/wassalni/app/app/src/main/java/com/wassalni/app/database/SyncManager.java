package com.wassalni.app.database;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import com.wassalni.app.api.RetrofitClient;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SyncManager {

    private static final String TAG = "SyncManager";

    private final Context context;
    private final long livreurId;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    public interface SyncCallback {
        void onSuccess(int nbLivraisons);
        void onError(String message);
    }

    public SyncManager(Context context, long livreurId) {
        this.context   = context;
        this.livreurId = livreurId;
    }

    public void synchroniser(SyncCallback callback) {
        RetrofitClient.getService()
                .getDetailLivraisonsLivreur(livreurId)
                .enqueue(new Callback<List<Map<String, Object>>>() {

                    @Override
                    public void onResponse(Call<List<Map<String, Object>>> call,
                                           Response<List<Map<String, Object>>> response) {

                        if (response.isSuccessful() && response.body() != null) {
                            List<Map<String, Object>> data = response.body();

                            executor.execute(() -> {
                                try {
                                    WassalniDatabase db = WassalniDatabase.getInstance(context);
                                    LivraisonDao dao = db.livraisonDao();

                                    String dateSync = new SimpleDateFormat(
                                            "yyyy-MM-dd HH:mm", Locale.getDefault())
                                            .format(new Date());

                                    for (Map<String, Object> item : data) {
                                        long nocde = getLong(item, "nocde");

                                        // ✅ Vérifier si modifiée localement AVANT d'écraser
                                        LivraisonLocale existante = dao.getLivraison(nocde);

                                        LivraisonLocale nouvelle = convertir(item, dateSync);

                                        if (existante != null && existante.modifieLocalement == 1) {
                                            // ✅ Garder l'état local, ne pas écraser
                                            nouvelle.etatliv          = existante.etatliv;
                                            nouvelle.remarque         = existante.remarque;
                                            nouvelle.nouvelEtat       = existante.nouvelEtat;
                                            nouvelle.modifieLocalement = 1;
                                        }

                                        dao.insererOuRemplacer(nouvelle);
                                    }

                                    int nb = data.size();
                                    mainHandler.post(() -> callback.onSuccess(nb));

                                } catch (Exception e) {
                                    Log.e(TAG, "Erreur sync SQLite", e);
                                    mainHandler.post(() -> callback.onError(e.getMessage()));
                                }
                            });

                        } else {
                            callback.onError("Réponse API invalide");
                        }
                    }

                    @Override
                    public void onFailure(Call<List<Map<String, Object>>> call, Throwable t) {
                        executor.execute(() -> {
                            WassalniDatabase db = WassalniDatabase.getInstance(context);
                            int nb = db.livraisonDao().compter();
                            mainHandler.post(() -> callback.onSuccess(nb));
                        });
                    }
                });
    }

    public void syncModificationsOffline() {
        executor.execute(() -> {
            WassalniDatabase db = WassalniDatabase.getInstance(context);
            List<LivraisonLocale> aSync = db.livraisonDao().getLivraisonsASync();

            for (LivraisonLocale liv : aSync) {
                java.util.Map<String, String> body = new java.util.HashMap<>();
                body.put("etatliv", liv.nouvelEtat);
                body.put("remarque", liv.remarque != null ? liv.remarque : "");

                try {
                    Response<Map<String, Object>> resp = RetrofitClient.getService()
                            .updateEtat(liv.nocde, body).execute();

                    if (resp.isSuccessful()) {
                        db.livraisonDao().marquerSynchronise(liv.nocde);
                    }
                } catch (Exception e) {
                    Log.w(TAG, "Impossible de sync #" + liv.nocde + " : " + e.getMessage());
                }
            }
        });
    }

    public void verifierEtSynchroniser(SyncCallback callback) {
        executor.execute(() -> {
            WassalniDatabase db = WassalniDatabase.getInstance(context);
            int nbLocal = db.livraisonDao().compter();

            mainHandler.post(() -> {
                if (nbLocal == 0) {
                    synchroniser(callback);
                } else {
                    callback.onSuccess(nbLocal);
                    synchroniser(new SyncCallback() {
                        @Override
                        public void onSuccess(int nbLivraisons) {}
                        @Override
                        public void onError(String message) {}
                    });
                }
            });
        });
    }

    private LivraisonLocale convertir(Map<String, Object> data, String dateSync) {
        LivraisonLocale liv = new LivraisonLocale();
        liv.nocde = getLong(data, "nocde");
        liv.etatliv = getString(data, "etatliv");
        liv.modepay = getString(data, "modepay");
        liv.dateliv = getString(data, "dateLivraison");
        liv.nomClient = getString(data, "nomClient");
        liv.prenomClient = getString(data, "prenomClient");
        liv.telClient = getString(data, "telClient");
        liv.adresseClient = getString(data, "adresseClient");
        liv.villeClient = getString(data, "villeClient");
        Object montant = data.get("montantTotal");
        liv.montantTotal = montant != null ? ((Number) montant).doubleValue() : 0;
        Object nbArt = data.get("nbArticles");
        liv.nbArticles = nbArt != null ? ((Number) nbArt).intValue() : 0;
        liv.dateSynchronisation = dateSync;
        liv.modifieLocalement = 0;
        return liv;
    }

    private String getString(Map<String, Object> map, String key) {
        Object val = map.get(key);
        return val != null ? val.toString() : "";
    }

    private long getLong(Map<String, Object> map, String key) {
        Object val = map.get(key);
        if (val == null) return 0;
        return ((Number) val).longValue();
    }
}

