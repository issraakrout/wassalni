// com/wassalni/app/adapter/LivraisonLivreurAdapter.java
package com.wassalni.app.adapter;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.wassalni.app.R;

import java.util.List;
import java.util.Map;

public class LivraisonLivreurAdapter extends
        RecyclerView.Adapter<LivraisonLivreurAdapter.ViewHolder> {

    private List<Map<String, Object>> livraisons;
    private Context context;
    private OnItemClickListener listener;

    public interface OnItemClickListener {
        void onItemClick(Map<String, Object> livraison);
    }

    public LivraisonLivreurAdapter(Context context,
                                   List<Map<String, Object>> livraisons,
                                   OnItemClickListener listener) {
        this.context    = context;
        this.livraisons = livraisons;
        this.listener   = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context)
                .inflate(R.layout.item_livraison_livreur, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder h, int position) {
        Map<String, Object> liv = livraisons.get(position);

        long nocde = ((Double) liv.get("nocde")).longValue();
        String etat = (String) liv.get("etatliv");

        // Numéro ordre
        h.tvOrdre.setText(String.valueOf(position + 1));

        // Titre : #nocde (le nom client sera ajouté via API détail)
        h.tvNomClient.setText("#" + nocde);

        // Date · ville
        String date = (String) liv.get("dateliv");
        h.tvTelVille.setText(date != null ? date : "—");

        // Mode paiement
        String modepay = (String) liv.get("modepay");
        h.tvModePay.setText(modepay != null ? modepay : "—");

        // État
        h.tvEtat.setText(etat != null ? etat : "—");
        appliquerCouleur(h, etat);

        // Clic
        h.itemView.setOnClickListener(v -> listener.onItemClick(liv));
    }

    private void appliquerCouleur(ViewHolder h, String etat) {
        if (etat == null) return;
        switch (etat) {
            case "Livrée":
                h.tvOrdre.setBackgroundResource(R.drawable.bg_ordre_circle);
                h.tvEtat.setTextColor(Color.parseColor("#1B7A3E"));
                h.tvEtat.setBackgroundResource(R.drawable.bg_badge_livree);
                break;
            case "En cours":
                h.tvEtat.setTextColor(Color.parseColor("#7A4F00"));
                h.tvEtat.setBackgroundResource(R.drawable.bg_badge_encours);
                break;
            default:
                h.tvEtat.setTextColor(Color.parseColor("#555555"));
                h.tvEtat.setBackgroundResource(R.drawable.bg_badge_livree);
                break;
        }
    }

    @Override
    public int getItemCount() { return livraisons.size(); }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvOrdre, tvNomClient, tvTelVille, tvMontant, tvModePay, tvEtat;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvOrdre     = itemView.findViewById(R.id.tvOrdre);
            tvNomClient = itemView.findViewById(R.id.tvNomClient);
            tvTelVille  = itemView.findViewById(R.id.tvTelVille);
            tvMontant   = itemView.findViewById(R.id.tvMontant);
            tvModePay   = itemView.findViewById(R.id.tvModePay);
            tvEtat      = itemView.findViewById(R.id.tvEtat);
        }
    }
}