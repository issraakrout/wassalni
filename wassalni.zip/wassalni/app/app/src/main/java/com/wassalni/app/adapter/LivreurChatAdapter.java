// com/wassalni/app/adapter/LivreurChatAdapter.java
package com.wassalni.app.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.wassalni.app.R;

import java.util.List;
import java.util.Map;

public class LivreurChatAdapter extends
        RecyclerView.Adapter<LivreurChatAdapter.ViewHolder> {

    private List<Map<String, Object>> livreurs;
    private Context context;
    private OnItemClickListener listener;

    public interface OnItemClickListener {
        void onItemClick(Map<String, Object> livreur);
    }

    public LivreurChatAdapter(Context context,
                              List<Map<String, Object>> livreurs,
                              OnItemClickListener listener) {
        this.context  = context;
        this.livreurs = livreurs;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context)
                .inflate(R.layout.item_livreur_chat, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder h, int position) {
        Map<String, Object> livreur = livreurs.get(position);

        String nom    = (String) livreur.get("nom");
        String prenom = (String) livreur.get("prenom");
        String gouv   = (String) livreur.get("gouvernorat");
        String dernierMsg = (String) livreur.getOrDefault("dernierMessage", "Aucun message");
        Object nonLusObj  = livreur.get("nonLus");
        int nonLus = nonLusObj != null ? ((Double) nonLusObj).intValue() : 0;

        // Initiales avatar
        String initiales = "";
        if (prenom != null && !prenom.isEmpty()) initiales += prenom.charAt(0);
        if (nom != null && !nom.isEmpty()) initiales += nom.charAt(0);
        h.tvAvatar.setText(initiales.toUpperCase());

        // Nom complet
        h.tvNomLivreur.setText(prenom + " " + nom);

        // Gouvernorat
        h.tvGouvernorat.setText(gouv != null ? gouv : "—");

        // Dernier message
        h.tvDernierMessage.setText(dernierMsg);

        // Badge non lus
        if (nonLus > 0) {
            h.badgeNonLus.setVisibility(View.VISIBLE);
            h.tvNbNonLus.setText(String.valueOf(nonLus));
        } else {
            h.badgeNonLus.setVisibility(View.GONE);
        }

        // Clic
        h.itemView.setOnClickListener(v -> listener.onItemClick(livreur));
    }

    @Override
    public int getItemCount() { return livreurs.size(); }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvAvatar, tvNomLivreur, tvGouvernorat, tvDernierMessage, tvNbNonLus;
        CardView badgeNonLus;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvAvatar         = itemView.findViewById(R.id.tvAvatar);
            tvNomLivreur     = itemView.findViewById(R.id.tvNomLivreur);
            tvGouvernorat    = itemView.findViewById(R.id.tvGouvernorat);
            tvDernierMessage = itemView.findViewById(R.id.tvDernierMessage);
            tvNbNonLus       = itemView.findViewById(R.id.tvNbNonLus);
            badgeNonLus      = itemView.findViewById(R.id.badgeNonLus);
        }
    }
}