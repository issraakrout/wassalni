// com/wassalni/app/database/LivraisonDao.java
package com.wassalni.app.database;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface LivraisonDao {

    // Insérer ou remplacer (lors de la sync du matin)
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insererOuRemplacer(LivraisonLocale livraison);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insererTout(List<LivraisonLocale> livraisons);

    // Récupérer toutes les livraisons du jour
    @Query("SELECT * FROM livraisons_locales ORDER BY nocde ASC")
    List<LivraisonLocale> getToutesLivraisons();

    // Récupérer une livraison par son numéro
    @Query("SELECT * FROM livraisons_locales WHERE nocde = :nocde")
    LivraisonLocale getLivraison(long nocde);

    // Mettre à jour l'état localement (mode offline)
    @Query("UPDATE livraisons_locales SET etatliv = :etat, " +
            "modifieLocalement = 1, nouvelEtat = :etat, remarque = :remarque " +
            "WHERE nocde = :nocde")
    void mettreAJourEtat(long nocde, String etat, String remarque);

    // Récupérer les livraisons modifiées hors ligne (à synchroniser)
    @Query("SELECT * FROM livraisons_locales WHERE modifieLocalement = 1")
    List<LivraisonLocale> getLivraisonsASync();

    // Marquer comme synchronisé après envoi à l'API
    @Query("UPDATE livraisons_locales SET modifieLocalement = 0 WHERE nocde = :nocde")
    void marquerSynchronise(long nocde);

    // Supprimer toutes les livraisons (avant nouvelle sync)
    @Query("DELETE FROM livraisons_locales")
    void supprimerTout();

    // Compter les livraisons par état
    @Query("SELECT COUNT(*) FROM livraisons_locales WHERE etatliv = :etat")
    int compterParEtat(String etat);

    // Vérifier si la base est vide
    @Query("SELECT COUNT(*) FROM livraisons_locales")
    int compter();
}