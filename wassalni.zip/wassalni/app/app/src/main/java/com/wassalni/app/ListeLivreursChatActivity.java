// com/wassalni/app/ListeLivreursChatActivity.java
package com.wassalni.app;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.wassalni.app.adapter.LivreurChatAdapter;
import com.wassalni.app.api.RetrofitClient;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ListeLivreursChatActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private LivreurChatAdapter adapter;
    private List<Map<String, Object>> livreurs = new ArrayList<>();

    private long idpers;
    private String prenom;
    private String role;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_liste_livreurs_chat);

        idpers = getIntent().getLongExtra("idpers", 0);
        prenom = getIntent().getStringExtra("prenom");
        role   = getIntent().getStringExtra("role");

        recyclerView = findViewById(R.id.recyclerLivreurs);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        adapter = new LivreurChatAdapter(this, livreurs, livreur -> {
            // Ouvrir le chat avec ce livreur
            long livreurId = ((Double) livreur.get("idpers")).longValue();
            String livreurPrenom = (String) livreur.get("prenom");
            String livreurNom    = (String) livreur.get("nom");

            Intent intent = new Intent(this, MessagerieActivity.class);
            intent.putExtra("idpers",        idpers);
            intent.putExtra("prenom",        prenom);
            intent.putExtra("role",          role);
            intent.putExtra("interlocuteur", livreurId);
            intent.putExtra("nomInterlocuteur", livreurPrenom + " " + livreurNom);
            startActivity(intent);
        });
        recyclerView.setAdapter(adapter);

        findViewById(R.id.btnRetour).setOnClickListener(v -> finish());

        chargerLivreurs();
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Rafraîchir les badges non lus quand on revient de la messagerie
        chargerLivreurs();
    }

    private void chargerLivreurs() {
        // 1. Charger la liste des livreurs
        RetrofitClient.getService().getLivreursDisponibles(idpers)
                .enqueue(new Callback<List<Map<String, Object>>>() {

                    @Override
                    public void onResponse(Call<List<Map<String, Object>>> call,
                                           Response<List<Map<String, Object>>> response) {
                        if (response.isSuccessful() && response.body() != null) {
                            livreurs.clear();

                            for (Map<String, Object> livreur : response.body()) {
                                // Copie modifiable
                                Map<String, Object> entry = new HashMap<>(livreur);
                                entry.put("dernierMessage", "Tap pour ouvrir le chat");
                                entry.put("nonLus", 0.0);
                                livreurs.add(entry);
                            }

                            adapter.notifyDataSetChanged();

                            // 2. Pour chaque livreur, charger les messages non lus
                            chargerNonLus();
                        }
                    }

                    @Override
                    public void onFailure(Call<List<Map<String, Object>>> call, Throwable t) {
                        Toast.makeText(ListeLivreursChatActivity.this,
                                "Erreur chargement", Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void chargerNonLus() {
        // Charger les messages non lus reçus par le contrôleur
        RetrofitClient.getService().getNonLus(idpers)
                .enqueue(new Callback<List<Map<String, Object>>>() {

                    @Override
                    public void onResponse(Call<List<Map<String, Object>>> call,
                                           Response<List<Map<String, Object>>> response) {
                        if (response.isSuccessful() && response.body() != null) {

                            // Compter les non lus par expéditeur
                            Map<Long, Integer> compteurs = new HashMap<>();
                            Map<Long, String>  derniers  = new HashMap<>();

                            for (Map<String, Object> msg : response.body()) {
                                long exp = ((Double) msg.get("expediteur")).longValue();
                                compteurs.merge(exp, 1, Integer::sum);
                                derniers.put(exp, (String) msg.get("contenu"));
                            }

                            // Mettre à jour chaque livreur
                            for (Map<String, Object> livreur : livreurs) {
                                long livId = ((Double) livreur.get("idpers")).longValue();
                                if (compteurs.containsKey(livId)) {
                                    livreur.put("nonLus", compteurs.get(livId).doubleValue());
                                    livreur.put("dernierMessage", derniers.get(livId));
                                }
                            }

                            adapter.notifyDataSetChanged();
                        }
                    }

                    @Override
                    public void onFailure(Call<List<Map<String, Object>>> call, Throwable t) {
                        // Silencieux
                    }
                });
    }
}