package com.wassalni.app;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.wassalni.app.api.RetrofitClient;
import com.wassalni.app.database.LivraisonDao;
import com.wassalni.app.database.LivraisonLocale;
import com.wassalni.app.database.WassalniDatabase;

import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DetailCommandeLivreurActivity extends AppCompatActivity {

    private static final String TAG = "DetailCommandeLivreur";
    private static final int REQUEST_CODE_MODIFIER_ETAT = 1;

    private long nocde;

    private TextView tvNocde, tvDateLiv, tvEtatLiv, tvModePay;
    private TextView tvNomClient, tvTelClient, tvAdresseClient;
    private TextView tvMontantTotal, tvNbArticles;
    private Button btnModifierEtat, btnUrgence;
    private View btnVoirSurCarte;
    private ImageView imgAppelClient, btnRetour;

    private LivraisonDao livraisonDao;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_commande_livreur);

        livraisonDao = WassalniDatabase.getInstance(this).livraisonDao();

        nocde = getIntent().getLongExtra("nocde", -1);
        if (nocde == -1) {
            Toast.makeText(this, "Numéro de commande invalide.", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        initViews();
        loadLivraisonDetails();

        btnModifierEtat.setOnClickListener(v -> {
            Intent intent = new Intent(DetailCommandeLivreurActivity.this, ModifierEtatActivity.class);
            intent.putExtra("nocde", nocde);
            intent.putExtra("etat", tvEtatLiv.getText().toString());
            intent.putExtra("nomClient", tvNomClient.getText().toString());
            // Nettoyage de la chaîne du montant pour le parse
            String montantStr = tvMontantTotal.getText().toString().replaceAll("[^0-9,.]", "").replace(",", ".");
            try {
                intent.putExtra("montantTotal", Double.parseDouble(montantStr));
            } catch (NumberFormatException e) {
                intent.putExtra("montantTotal", 0.0);
            }
            startActivityForResult(intent, REQUEST_CODE_MODIFIER_ETAT);
        });

        btnUrgence.setOnClickListener(v -> afficherDialogueUrgence());

        btnVoirSurCarte.setOnClickListener(v -> {
            String adresse = tvAdresseClient.getText().toString();
            Uri gmmIntentUri = Uri.parse("geo:0,0?q=" + Uri.encode(adresse));
            Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
            mapIntent.setPackage("com.google.android.apps.maps");
            if (mapIntent.resolveActivity(getPackageManager()) != null) {
                startActivity(mapIntent);
            } else {
                Toast.makeText(DetailCommandeLivreurActivity.this, "Google Maps n'est pas installé.", Toast.LENGTH_SHORT).show();
            }
        });

        imgAppelClient.setOnClickListener(v -> {
            String phoneNumber = tvTelClient.getText().toString();
            if (!phoneNumber.isEmpty()) {
                Intent dialIntent = new Intent(Intent.ACTION_DIAL);
                dialIntent.setData(Uri.parse("tel:" + phoneNumber));
                if (dialIntent.resolveActivity(getPackageManager()) != null) {
                    startActivity(dialIntent);
                } else {
                    Toast.makeText(DetailCommandeLivreurActivity.this, "Impossible de passer un appel.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnRetour.setOnClickListener(v -> finish());
    }

    private void initViews() {
        tvNocde = findViewById(R.id.tvTitreCommande);
        tvDateLiv = findViewById(R.id.tvDateLivraison);
        tvEtatLiv = findViewById(R.id.tvBadgeEtat);
        tvModePay = findViewById(R.id.tvModePay);
        tvNomClient = findViewById(R.id.tvNomClient);
        tvTelClient = findViewById(R.id.tvTelClient);
        tvAdresseClient = findViewById(R.id.tvAdresseClient);
        tvMontantTotal = findViewById(R.id.tvMontant);
        tvNbArticles = findViewById(R.id.tvNbArticles);
        btnModifierEtat = findViewById(R.id.btnModifierEtat);
        btnUrgence = findViewById(R.id.btnUrgence);
        btnVoirSurCarte = findViewById(R.id.btnGoogleMaps);
        imgAppelClient = findViewById(R.id.imgAppelClient);
        btnRetour = findViewById(R.id.btnRetour);
    }

    private void afficherDialogueUrgence() {
        new AlertDialog.Builder(this)
                .setTitle("🚨 Signalement d'urgence")
                .setMessage("Souhaitez-vous signaler un problème grave sur cette livraison au contrôleur ?")
                .setPositiveButton("Signaler", (dialog, which) -> {
                    Toast.makeText(this, "Alerte envoyée au contrôleur !", Toast.LENGTH_LONG).show();
                    // Ici on pourrait ajouter un appel API pour notifier le contrôleur
                })
                .setNegativeButton("Annuler", null)
                .setIcon(android.R.drawable.ic_dialog_alert)
                .show();
    }

    private void loadLivraisonDetails() {
        executor.execute(() -> {
            LivraisonLocale livraisonLocale = livraisonDao.getLivraison(nocde);
            runOnUiThread(() -> {
                if (livraisonLocale != null) {
                    displayLivraisonDetails(livraisonLocale);
                    Log.d(TAG, "Détails de la livraison " + nocde + " chargés depuis la base de données locale.");
                } else {
                    Log.d(TAG, "Livraison " + nocde + " non trouvée localement. Tentative de chargement via API.");
                }
                fetchLivraisonDetailsFromApi();
            });
        });
    }

    private void fetchLivraisonDetailsFromApi() {
        RetrofitClient.getService().getDetailLivraison(nocde)
                .enqueue(new Callback<Map<String, Object>>() {

                    @Override
                    public void onResponse(Call<Map<String, Object>> call,
                                           Response<Map<String, Object>> response) {
                        if (response.isSuccessful() && response.body() != null) {
                            Map<String, Object> data = response.body();

                            executor.execute(() -> {
                                // ✅ Lire l'état local AVANT d'écraser
                                LivraisonLocale locale = livraisonDao.getLivraison(nocde);
                                LivraisonLocale updated = convertApiDataToLivraisonLocale(data);

                                // ✅ Si modifiée offline → protéger l'état local
                                if (locale != null && locale.modifieLocalement == 1) {
                                    updated.etatliv          = locale.etatliv;
                                    updated.remarque         = locale.remarque;
                                    updated.modifieLocalement = 1;
                                    updated.nouvelEtat       = locale.nouvelEtat;
                                }

                                livraisonDao.insererOuRemplacer(updated);

                                runOnUiThread(() -> displayLivraisonDetails(updated));
                            });
                        }
                    }

                    @Override
                    public void onFailure(Call<Map<String, Object>> call, Throwable t) {
                        Log.e(TAG, "Hors ligne: " + t.getMessage());
                    }
                });
    }

    private void displayLivraisonDetails(LivraisonLocale livraison) {
        tvNocde.setText("#" + livraison.nocde);
        tvDateLiv.setText(livraison.dateliv);
        tvEtatLiv.setText(livraison.etatliv);
        tvModePay.setText(livraison.modepay);
        tvNomClient.setText(livraison.nomClient + " " + livraison.prenomClient);
        tvTelClient.setText(livraison.telClient);
        tvAdresseClient.setText(livraison.adresseClient + ", " + livraison.villeClient);
        tvMontantTotal.setText(String.format("%.3f DT", livraison.montantTotal));
        tvNbArticles.setText(livraison.nbArticles + " articles");
    }

    private LivraisonLocale convertApiDataToLivraisonLocale(Map<String, Object> data) {
        LivraisonLocale liv = new LivraisonLocale();
        liv.nocde = getLong(data, "nocde");
        liv.etatliv = getString(data, "etatliv");
        liv.modepay = getString(data, "modepay");
        liv.dateliv = getString(data, "dateLivraison");
        liv.nomClient = getString(data, "nomClient");
        liv.prenomClient = getString(data, "prenomClient");
        liv.telClient = getString(data, "telClient");
        liv.adresseClient = getString(data, "adresseClient");
        liv.villeClient = getString(data, "villeClient");
        Object montant = data.get("montantTotal");
        liv.montantTotal = montant != null ? ((Number) montant).doubleValue() : 0;
        Object nbArt = data.get("nbArticles");
        liv.nbArticles = nbArt != null ? ((Number) nbArt).intValue() : 0;
        return liv;
    }

    private String getString(Map<String, Object> map, String key) {
        Object val = map.get(key);
        return val != null ? val.toString() : "";
    }

    private long getLong(Map<String, Object> map, String key) {
        Object val = map.get(key);
        if (val == null) return 0;
        return ((Number) val).longValue();
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE_MODIFIER_ETAT && resultCode == RESULT_OK) {

            // ✅ D'abord afficher depuis SQLite immédiatement
            executor.execute(() -> {
                LivraisonLocale locale = livraisonDao.getLivraison(nocde);
                if (locale != null) {
                    runOnUiThread(() -> displayLivraisonDetails(locale));
                }
            });

            // ✅ Puis rafraîchir depuis API après 2 secondes
            new Handler(Looper.getMainLooper()).postDelayed(() -> {
                fetchLivraisonDetailsFromApi();
            }, 2000); // 2 secondes pour laisser Oracle commiter
        }
    }
}
