package com.wassalni.app.database;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.room.migration.Migration;
import androidx.sqlite.db.SupportSQLiteDatabase;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Database(entities = {LivraisonLocale.class}, version = 2, exportSchema = false) // Version incrémentée à 2
public abstract class WassalniDatabase extends RoomDatabase {

    public abstract LivraisonDao livraisonDao();

    private static volatile WassalniDatabase INSTANCE;
    private static final int NUMBER_OF_THREADS = 4;
    static final ExecutorService databaseWriteExecutor = Executors.newFixedThreadPool(NUMBER_OF_THREADS);

    public static WassalniDatabase getInstance(final Context context) {
        if (INSTANCE == null) {
            synchronized (WassalniDatabase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(context.getApplicationContext(),
                                    WassalniDatabase.class, "wassalni_db")
                            // .fallbackToDestructiveMigration() // Supprimer cette ligne
                            .addMigrations(MIGRATION_1_2) // Ajouter la migration ici
                            .build();
                }
            }
        }
        return INSTANCE;
    }

    // Exemple de migration : Ajout du champ nbArticles si ce n'était pas déjà fait
    // (Assurez-vous que LivraisonLocale.java a déjà le champ nbArticles)
    static final Migration MIGRATION_1_2 = new Migration(1, 2) {
        @Override
        public void migrate(SupportSQLiteDatabase database) {
            // Si le champ nbArticles n'existait pas dans la version 1, l'ajouter ici.
            // Si vous avez déjà le champ nbArticles dans LivraisonLocale et que la base de données
            // a été créée avec, cette migration peut être vide ou ajouter d'autres champs.
            // Exemple d'ajout d'une colonne (si elle n'existe pas déjà)
            // database.execSQL("ALTER TABLE livraisons_locales ADD COLUMN nbArticles INTEGER NOT NULL DEFAULT 0");
            // Pour cet exemple, nous supposons que nbArticles existait déjà mais n'était pas peuplé.
            // Si vous avez d'autres changements de schéma, ajoutez-les ici.
        }
    };
}
