package com.wassalni.app.database;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "livraisons_locales")
public class LivraisonLocale {

    @PrimaryKey
    public long nocde;

    public String dateliv;
    public String etatliv;
    public String modepay;

    // Infos client (dénormalisées pour accès rapide hors ligne)
    public String nomClient;
    public String prenomClient;
    public String telClient;
    public String adresseClient;
    public String villeClient;

    // Infos commande
    public double montantTotal;
    public int nbArticles; // Assurez-vous que ce champ est présent

    // Sync
    public String dateSynchronisation; // quand a-t-on téléchargé cette livraison ?
    public int modifieLocalement;      // 1 = modifié offline, à synchroniser
    public String nouvelEtat;          // état modifié en offline
    public String remarque;            // remarque si non livrée
}

