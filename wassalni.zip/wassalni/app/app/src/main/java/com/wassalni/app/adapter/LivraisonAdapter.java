package com.wassalni.app.adapter;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.wassalni.app.DetailLivraisonActivity;
import com.wassalni.app.R;

import java.util.List;
import java.util.Map;

public class LivraisonAdapter extends RecyclerView.Adapter<LivraisonAdapter.ViewHolder> {

    private List<Map<String, Object>> livraisons;
    private Context context;
    private OnItemClickListener listener;

    public interface OnItemClickListener {
        void onItemClick(Map<String, Object> livraison);
    }

    public LivraisonAdapter(Context context,
                            List<Map<String, Object>> livraisons,
                            OnItemClickListener listener) {
        this.context = context;
        this.livraisons = livraisons;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context)
                .inflate(R.layout.item_livraison, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Map<String, Object> liv = livraisons.get(position);

        // Numéro commande
        Object nocdeObj = liv.get("nocde");
        long nocde = 0;
        if (nocdeObj instanceof Double) {
            nocde = ((Double) nocdeObj).longValue();
        } else if (nocdeObj instanceof Long) {
            nocde = (Long) nocdeObj;
        } else if (nocdeObj instanceof Integer) {
            nocde = (Integer) nocdeObj;
        }
        holder.tvNumCde.setText("#" + nocde);

        // État + couleurs
        String etat = (String) liv.get("etatliv");
        holder.tvEtat.setText(etat != null ? etat : "—");
        appliquerCouleurEtat(holder, etat);

        // Date
        String date = (String) liv.get("dateliv");
        String dateAffiche = (date != null && date.length() >= 10) ? date.substring(5).replace("-", "/") : "—";

        // Infos livreur/client
        holder.tvInfos.setText("Livreur #" + liv.get("livreur"));
        holder.tvDateMontant.setText(dateAffiche);

        // Clic
        long finalNocde = nocde;
        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, DetailLivraisonActivity.class);
            intent.putExtra("nocde", finalNocde);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
        });
    }

    private void appliquerCouleurEtat(ViewHolder h, String etat) {
        if (etat == null) return;
        switch (etat) {
            case "Livrée":
                h.barreEtat.setBackgroundColor(Color.parseColor("#2ECC71"));
                h.tvEtat.setTextColor(Color.parseColor("#1B7A3E"));
                h.tvEtat.setBackgroundResource(R.drawable.bg_badge_livree);
                break;
            case "En cours":
                h.barreEtat.setBackgroundColor(Color.parseColor("#F39C12"));
                h.tvEtat.setTextColor(Color.parseColor("#7A4F00"));
                h.tvEtat.setBackgroundResource(R.drawable.bg_badge_encours);
                break;
            case "Non livrée":
                h.barreEtat.setBackgroundColor(Color.parseColor("#E74C3C"));
                h.tvEtat.setTextColor(Color.parseColor("#7A1E1E"));
                h.tvEtat.setBackgroundResource(R.drawable.bg_badge_nonlivree);
                break;
            default:
                h.barreEtat.setBackgroundColor(Color.parseColor("#AAAAAA"));
                h.tvEtat.setTextColor(Color.parseColor("#555555"));
                h.tvEtat.setBackgroundResource(R.drawable.bg_badge_livree);
                break;
        }
    }

    @Override
    public int getItemCount() {
        return livraisons.size();
    }

    public void updateData(List<Map<String, Object>> newData) {
        this.livraisons = newData;
        notifyDataSetChanged();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvNumCde, tvEtat, tvInfos, tvDateMontant;
        View barreEtat;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvNumCde = itemView.findViewById(R.id.tvNumCde);
            tvEtat = itemView.findViewById(R.id.tvEtat);
            tvInfos = itemView.findViewById(R.id.tvInfos);
            tvDateMontant = itemView.findViewById(R.id.tvDateMontant);
            barreEtat = itemView.findViewById(R.id.barreEtat);
        }
    }
}
