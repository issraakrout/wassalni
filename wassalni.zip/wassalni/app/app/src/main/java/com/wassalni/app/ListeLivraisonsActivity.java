package com.wassalni.app;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.wassalni.app.adapter.LivraisonAdapter;
import com.wassalni.app.api.RetrofitClient;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ListeLivraisonsActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private LivraisonAdapter adapter;
    private TextView tvCompteur;
    private List<Map<String, Object>> toutesLivraisons = new ArrayList<>();
    private List<Map<String, Object>> livraisonsFiltrees = new ArrayList<>();

    private String prenom;
    private long idpers;

    // Filtres
    private TextView tvDateDebut, tvDateFin;
    private TextView filterEtat, filterLivreur, filterClient, filterNumCde;
    private Calendar calDebut, calFin;
    
    // Valeurs des filtres
    private String queryLivreur = "";
    private String queryClient = "";
    private String queryNumCde = "";
    private String queryEtat = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_liste_livraisons);

        prenom = getIntent().getStringExtra("prenom");
        idpers = getIntent().getLongExtra("idpers", 0);

        tvCompteur  = findViewById(R.id.tvCompteur);
        recyclerView = findViewById(R.id.recyclerLivraisons);
        tvDateDebut = findViewById(R.id.tvDateDebut);
        tvDateFin = findViewById(R.id.tvDateFin);
        
        filterEtat = findViewById(R.id.filterEtat);
        filterLivreur = findViewById(R.id.filterLivreur);
        filterClient = findViewById(R.id.filterClient);
        filterNumCde = findViewById(R.id.filterNumCde);

        // Initialiser RecyclerView
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new LivraisonAdapter(this, livraisonsFiltrees, liv -> {
            long nocde = extractLong(liv, "nocde");
            Intent intent = new Intent(this, DetailLivraisonActivity.class);
            intent.putExtra("nocde", nocde);
            intent.putExtra("prenom", prenom);
            intent.putExtra("idpers", idpers);
            startActivity(intent);
        });
        recyclerView.setAdapter(adapter);

        setupFiltres();
        chargerLivraisons();

        // Bottom nav
        findViewById(R.id.navAccueil).setOnClickListener(v -> finish());
        findViewById(R.id.navStats).setOnClickListener(v ->
                Toast.makeText(this, "Stats — bientôt", Toast.LENGTH_SHORT).show());
        findViewById(R.id.navMessages).setOnClickListener(v ->
                Toast.makeText(this, "Messages — bientôt", Toast.LENGTH_SHORT).show());
    }

    private void setupFiltres() {
        calDebut = Calendar.getInstance();
        calDebut.add(Calendar.MONTH, -1); // Par défaut 1 mois en arrière
        calFin = Calendar.getInstance();
        
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy", Locale.FRANCE);
        tvDateDebut.setText(sdf.format(calDebut.getTime()));
        tvDateFin.setText(sdf.format(calFin.getTime()));

        findViewById(R.id.btnDateDebut).setOnClickListener(v -> showDatePicker(true));
        findViewById(R.id.btnDateFin).setOnClickListener(v -> showDatePicker(false));

        filterLivreur.setOnClickListener(v -> showSearchDialog("Livreur", "livreur"));
        filterClient.setOnClickListener(v -> showSearchDialog("Client", "client"));
        filterNumCde.setOnClickListener(v -> showSearchDialog("N° Commande", "numcde"));
        filterEtat.setOnClickListener(v -> showEtatDialog());
    }

    private void showDatePicker(boolean isDebut) {
        Calendar cal = isDebut ? calDebut : calFin;
        new DatePickerDialog(this, (view, year, month, dayOfMonth) -> {
            cal.set(year, month, dayOfMonth);
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy", Locale.FRANCE);
            if (isDebut) tvDateDebut.setText(sdf.format(cal.getTime()));
            else tvDateFin.setText(sdf.format(cal.getTime()));
            appliquerFiltres();
        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show();
    }

    private void showSearchDialog(String title, String type) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Filtrer par " + title);

        final EditText input = new EditText(this);
        String currentVal = "";
        if (type.equals("livreur")) currentVal = queryLivreur;
        else if (type.equals("client")) currentVal = queryClient;
        else if (type.equals("numcde")) currentVal = queryNumCde;
        
        input.setText(currentVal);
        input.setHint("Entrez le " + title.toLowerCase());
        input.setPadding(50, 40, 50, 40);
        builder.setView(input);

        builder.setPositiveButton("Filtrer", (dialog, which) -> {
            String val = input.getText().toString().trim();
            if (type.equals("livreur")) {
                queryLivreur = val;
                updatePillUI(filterLivreur, !queryLivreur.isEmpty(), "Livreur" + (queryLivreur.isEmpty() ? "" : ": " + queryLivreur));
            } else if (type.equals("client")) {
                queryClient = val;
                updatePillUI(filterClient, !queryClient.isEmpty(), "Client" + (queryClient.isEmpty() ? "" : ": " + queryClient));
            } else if (type.equals("numcde")) {
                queryNumCde = val;
                updatePillUI(filterNumCde, !queryNumCde.isEmpty(), "N° cde" + (queryNumCde.isEmpty() ? "" : ": " + queryNumCde));
            }
            appliquerFiltres();
        });
        builder.setNegativeButton("Annuler", null);
        builder.setNeutralButton("Effacer", (dialog, which) -> {
            if (type.equals("livreur")) {
                queryLivreur = "";
                updatePillUI(filterLivreur, false, "Livreur");
            } else if (type.equals("client")) {
                queryClient = "";
                updatePillUI(filterClient, false, "Client");
            } else if (type.equals("numcde")) {
                queryNumCde = "";
                updatePillUI(filterNumCde, false, "N° cde");
            }
            appliquerFiltres();
        });
        builder.show();
    }

    private void showEtatDialog() {
        String[] etats = {"Livrée", "En cours", "Non livrée", "Toutes"};
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Filtrer par état");
        builder.setItems(etats, (dialog, which) -> {
            if (which == 3) {
                queryEtat = "";
                updatePillUI(filterEtat, false, "État");
            } else {
                queryEtat = etats[which];
                updatePillUI(filterEtat, true, queryEtat);
            }
            appliquerFiltres();
        });
        builder.show();
    }

    private void updatePillUI(TextView tv, boolean selected, String text) {
        tv.setText(text);
        if (selected) {
            tv.setBackgroundResource(R.drawable.bg_pill_selected);
            tv.setTextColor(ContextCompat.getColor(this, android.R.color.white));
        } else {
            tv.setBackgroundResource(R.drawable.bg_pill_unselected);
            tv.setTextColor(Color.parseColor("#555555"));
        }
    }

    private void appliquerFiltres() {
        livraisonsFiltrees.clear();
        SimpleDateFormat sdfApi = new SimpleDateFormat("yyyy-MM-dd", Locale.US);

        long startMs = getStartOfDay(calDebut.getTimeInMillis());
        long endMs = getEndOfDay(calFin.getTimeInMillis());

        for (Map<String, Object> liv : toutesLivraisons) {
            // 1. Filtre Date
            String dateStr = getString(liv, "dateliv");
            if (dateStr.length() >= 10) {
                try {
                    long itemTime = sdfApi.parse(dateStr.substring(0, 10)).getTime();
                    if (itemTime < startMs || itemTime > endMs) continue;
                } catch (Exception ignored) {}
            }

            // 2. Filtre État
            if (!queryEtat.isEmpty()) {
                if (!getString(liv, "etatliv").equalsIgnoreCase(queryEtat)) continue;
            }

            // 3. Filtre Livreur (nom ou id)
            if (!queryLivreur.isEmpty()) {
                String nomLiv = (getString(liv, "nomLivreur") + " " + getString(liv, "prenomLivreur")).toLowerCase();
                String idLiv = getString(liv, "livreur").toLowerCase();
                if (!nomLiv.contains(queryLivreur.toLowerCase()) && !idLiv.contains(queryLivreur.toLowerCase())) continue;
            }

            // 4. Filtre Client
            if (!queryClient.isEmpty()) {
                String nomClt = (getString(liv, "nomClient") + " " + getString(liv, "prenomClient")).toLowerCase();
                if (!nomClt.contains(queryClient.toLowerCase())) continue;
            }

            // 5. Filtre Num Commande
            if (!queryNumCde.isEmpty()) {
                String nocde = String.valueOf(extractLong(liv, "nocde"));
                if (!nocde.contains(queryNumCde)) continue;
            }

            livraisonsFiltrees.add(liv);
        }

        adapter.updateData(livraisonsFiltrees);
        tvCompteur.setText(livraisonsFiltrees.size() + " livraisons trouvées");
    }

    private void chargerLivraisons() {
        tvCompteur.setText("Chargement...");
        RetrofitClient.getService().getAllLivraisons().enqueue(new Callback<List<Map<String, Object>>>() {
            @Override
            public void onResponse(Call<List<Map<String, Object>>> call, Response<List<Map<String, Object>>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    toutesLivraisons.clear();
                    toutesLivraisons.addAll(response.body());
                    appliquerFiltres();
                }
            }
            @Override
            public void onFailure(Call<List<Map<String, Object>>> call, Throwable t) {
                tvCompteur.setText("Erreur réseau");
            }
        });
    }

    // Helpers
    private String getString(Map<String, Object> map, String key) {
        Object val = map.get(key);
        return val != null ? val.toString() : "";
    }

    private long extractLong(Map<String, Object> map, String key) {
        Object obj = map.get(key);
        if (obj instanceof Double) return ((Double) obj).longValue();
        if (obj instanceof Long) return (Long) obj;
        if (obj instanceof Integer) return (Integer) obj;
        try { return Long.parseLong(String.valueOf(obj)); } catch (Exception e) { return 0; }
    }

    private long getStartOfDay(long ms) {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(ms);
        c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0);
        return c.getTimeInMillis();
    }

    private long getEndOfDay(long ms) {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(ms);
        c.set(Calendar.HOUR_OF_DAY, 23); c.set(Calendar.MINUTE, 59); c.set(Calendar.SECOND, 59); c.set(Calendar.MILLISECOND, 999);
        return c.getTimeInMillis();
    }
}
