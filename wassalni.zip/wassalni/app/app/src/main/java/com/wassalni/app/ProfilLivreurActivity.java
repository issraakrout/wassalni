package com.wassalni.app;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.wassalni.app.api.RetrofitClient;
import com.wassalni.app.database.WassalniDatabase;

import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ProfilLivreurActivity extends AppCompatActivity {

    private TextView tvNomComplet, tvEmail, tvTelephone, tvZone, tvNomControleur;
    private ImageView ivAvatar;
    private long idpers;
    private long idControleur = -1;
    private ExecutorService executor = Executors.newSingleThreadExecutor();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profil_livreur);

        idpers = getIntent().getLongExtra("idpers", -1);
        String intentPrenom = getIntent().getStringExtra("prenom");
        String intentNom = getIntent().getStringExtra("nom");

        tvNomComplet   = findViewById(R.id.tvNomComplet);
        tvEmail        = findViewById(R.id.tvEmail);
        tvTelephone    = findViewById(R.id.tvTelephone);
        tvZone         = findViewById(R.id.tvZone);
        tvNomControleur = findViewById(R.id.tvNomControleur);
        ivAvatar       = findViewById(R.id.ivAvatar);

        if (intentPrenom != null && intentNom != null) {
            tvNomComplet.setText(prenomCase(intentPrenom) + " " + nomCase(intentNom));
        }

        findViewById(R.id.btnBack).setOnClickListener(v -> finish());
        
        findViewById(R.id.btnLogout).setOnClickListener(v -> {
            Intent intent = new Intent(this, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
        });

        findViewById(R.id.btnMessageControleur).setOnClickListener(v -> {
            if (idControleur != -1) {
                Intent intent = new Intent(this, MessagerieActivity.class);
                intent.putExtra("idpers", idpers);
                intent.putExtra("interlocuteur", idControleur);
                intent.putExtra("role", "LIV");
                startActivity(intent);
            } else {
                Toast.makeText(this, "Contrôleur non assigné", Toast.LENGTH_SHORT).show();
            }
        });

        chargerProfil();
    }

    private void chargerProfil() {
        RetrofitClient.getService().getProfilLivreur(idpers).enqueue(new Callback<Map<String, Object>>() {
            @Override
            public void onResponse(Call<Map<String, Object>> call, Response<Map<String, Object>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    Map<String, Object> data = response.body();
                    updateUI(data);
                } else {
                    chargerDepuisLocal();
                }
            }

            @Override
            public void onFailure(Call<Map<String, Object>> call, Throwable t) {
                chargerDepuisLocal();
            }
        });
    }

    private void updateUI(Map<String, Object> data) {
        String nom = String.valueOf(data.get("nom"));
        String prenom = String.valueOf(data.get("prenom"));
        tvNomComplet.setText(prenomCase(prenom) + " " + nomCase(nom));
        
        tvEmail.setText("Email : " + getValue(data, "email"));
        tvTelephone.setText("Téléphone : " + getValue(data, "tel"));
        
        // Zone couverte (Gouvernorat)
        String zone = getValue(data, "zone");
        if (zone.equals("-")) zone = getValue(data, "ville");
        tvZone.setText("Zone couverte : " + zone);

        Map<String, Object> ctrl = (Map<String, Object>) data.get("controleur");
        if (ctrl != null) {
            String nomC = String.valueOf(ctrl.get("nom"));
            String prenomC = String.valueOf(ctrl.get("prenom"));
            tvNomControleur.setText(prenomCase(prenomC) + " " + nomCase(nomC));
            
            Object idC = ctrl.get("idpers");
            if (idC instanceof Number) {
                idControleur = ((Number) idC).longValue();
            }
        }
        
        // Charger la photo si disponible dans l'API
        String photoUrl = getValue(data, "photoUrl");
        if (!photoUrl.equals("-")) {
            Glide.with(this).load(photoUrl).placeholder(R.drawable.bg_role_unselected).into(ivAvatar);
        } else {
            chargerPhotoParDefaut();
        }
    }

    private void chargerDepuisLocal() {
        String infoTel = "-";
        String infoZone = "-";
        String email = "-";
        String nomCtrl = "Karim Bensalah";
        idControleur = 1; // Par défaut Karim
        String photoUrl = "";

        if (idpers == 2) { // Riadh Belkasem
            infoTel = "+216 98 112 233";
            infoZone = "Ariana";
            email = "r.belkasem@wassalni.tn";
            nomCtrl = "Karim Bensalah";
            idControleur = 1;
            photoUrl = "https://randomuser.me/api/portraits/men/32.jpg";
        } else if (idpers == 3) { // Ali Kamal
            infoTel = "+216 55 333 444";
            infoZone = "Tunis";
            email = "a.kamal@wassalni.tn";
            nomCtrl = "Karim Bensalah";
            idControleur = 1;
            photoUrl = "https://randomuser.me/api/portraits/men/44.jpg";
        } else if (idpers == 4) { // Sami Trabelsi
            infoTel = "+216 77 555 666";
            infoZone = "La Marsa";
            email = "s.trabelsi@wassalni.tn";
            nomCtrl = "Nadia Mansouri";
            idControleur = 5;
            photoUrl = "https://randomuser.me/api/portraits/men/85.jpg";
        } else if (idpers == 6) { // Mehdi Gharbi
            infoTel = "+216 55 777 888";
            infoZone = "Manouba";
            email = "m.gharbi@wassalni.tn";
            nomCtrl = "Nadia Mansouri";
            idControleur = 5;
            photoUrl = "https://randomuser.me/api/portraits/men/22.jpg";
        }

        final String fTel = infoTel;
        final String fZone = infoZone;
        final String fEml = email;
        final String fCtrl = nomCtrl;
        final String fPhoto = photoUrl;

        runOnUiThread(() -> {
            tvTelephone.setText("Téléphone : " + fTel);
            tvZone.setText("Zone couverte : " + fZone);
            tvEmail.setText("Email : " + fEml);
            tvNomControleur.setText(fCtrl);
            
            if (!fPhoto.isEmpty()) {
                Glide.with(this).load(fPhoto).circleCrop().into(ivAvatar);
            }
        });
    }

    private void chargerPhotoParDefaut() {
        // Optionnel : charger une photo basée sur l'ID même si l'API ne renvoie rien
        chargerDepuisLocal();
    }

    private String getValue(Map<String, Object> data, String key) {
        Object val = data.get(key);
        return (val != null && !val.toString().equals("null")) ? val.toString() : "-";
    }

    private String prenomCase(String s) {
        if (s == null || s.isEmpty()) return "";
        return s.substring(0, 1).toUpperCase() + s.substring(1).toLowerCase();
    }

    private String nomCase(String s) {
        if (s == null || s.isEmpty()) return "";
        return s.toUpperCase();
    }
}
