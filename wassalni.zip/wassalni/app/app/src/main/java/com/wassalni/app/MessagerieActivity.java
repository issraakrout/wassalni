// com/wassalni/app/MessagerieActivity.java
package com.wassalni.app;

import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.wassalni.app.api.RetrofitClient;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MessagerieActivity extends AppCompatActivity {

    private LinearLayout containerMessages;
    private ScrollView scrollView;
    private EditText etMessage;
    private View btnEnvoyer; 
    private TextView tvTitre;
    private LinearLayout containerQuickMessages;
    private View scrollQuickMessages;

    private long idpers;       
    private long interlocuteur; 
    private String prenom;
    private String role;
    private long nocde;
    private boolean isUrgence;
    private String nomInterlocuteur;

    private Handler handler = new Handler();
    private Runnable refreshRunnable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_messagerie);

        idpers           = getIntent().getLongExtra("idpers", 0);
        prenom           = getIntent().getStringExtra("prenom");
        role             = getIntent().getStringExtra("role");
        interlocuteur    = getIntent().getLongExtra("interlocuteur", 0);
        nocde            = getIntent().getLongExtra("nocde", 0);
        isUrgence        = getIntent().getBooleanExtra("urgence", false);
        nomInterlocuteur = getIntent().getStringExtra("nomInterlocuteur");

        containerMessages      = findViewById(R.id.containerMessages);
        scrollView             = findViewById(R.id.scrollMessages);
        etMessage              = findViewById(R.id.etMessage);
        btnEnvoyer             = findViewById(R.id.btnEnvoyer);
        tvTitre                = findViewById(R.id.tvLivreurs);
        containerQuickMessages = findViewById(R.id.containerQuickMessages);
        scrollQuickMessages    = findViewById(R.id.scrollQuickMessages);

        if (nomInterlocuteur != null && !nomInterlocuteur.isEmpty()) {
            tvTitre.setText(nomInterlocuteur);
        } else {
            tvTitre.setText("Discussion");
        }

        if (interlocuteur == 0) {
            interlocuteur = "LIV".equals(role) ? 1L : 2L; 
        }

        if ("LIV".equals(role)) {
            setupQuickMessages();
        }

        btnEnvoyer.setOnClickListener(v -> envoyerMessage());
        findViewById(R.id.btnRetour).setOnClickListener(v -> finish());

        // Marquer comme lu et charger
        marquerCommeLus();
        chargerConversation();

        refreshRunnable = () -> {
            marquerCommeLus(); // On marque comme lu à chaque rafraîchissement
            chargerConversation();
            handler.postDelayed(refreshRunnable, 10000);
        };
        handler.postDelayed(refreshRunnable, 10000);
    }

    private void marquerCommeLus() {
        if (idpers == 0 || interlocuteur == 0) return;
        RetrofitClient.getService().marquerConversationLue(idpers, interlocuteur)
                .enqueue(new Callback<Void>() {
                    @Override
                    public void onResponse(Call<Void> call, Response<Void> response) {}
                    @Override
                    public void onFailure(Call<Void> call, Throwable t) {}
                });
    }

    private void setupQuickMessages() {
        scrollQuickMessages.setVisibility(View.VISIBLE);
        String[] quickMsgs = {"Je suis arrivé !", "Client absent.", "J'ai besoin d'aide.", "Livraison terminée."};
        for (String msg : quickMsgs) {
            CardView card = new CardView(this);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            params.setMargins(0, 0, 12, 0);
            card.setLayoutParams(params);
            card.setRadius(30f);
            card.setCardElevation(2f);
            card.setCardBackgroundColor(Color.parseColor("#E3F2FD"));
            TextView tv = new TextView(this);
            tv.setText(msg);
            tv.setPadding(30, 15, 30, 15);
            tv.setTextColor(Color.parseColor("#1565C0"));
            card.addView(tv);
            card.setOnClickListener(v -> { etMessage.setText(msg); envoyerMessage(); });
            containerQuickMessages.addView(card);
        }
    }

    private void chargerConversation() {
        if (idpers == 0 || interlocuteur == 0) return;
        RetrofitClient.getService().getConversation(idpers, interlocuteur)
                .enqueue(new Callback<List<Map<String, Object>>>() {
                    @Override
                    public void onResponse(Call<List<Map<String, Object>>> call, Response<List<Map<String, Object>>> response) {
                        if (response.isSuccessful() && response.body() != null) {
                            afficherMessages(response.body());
                        }
                    }
                    @Override
                    public void onFailure(Call<List<Map<String, Object>>> call, Throwable t) {}
                });
    }

    private void afficherMessages(List<Map<String, Object>> messages) {
        containerMessages.removeAllViews();
        for (Map<String, Object> msg : messages) {
            Object expObj = msg.get("expediteur");
            if (expObj == null) continue;
            
            long expediteurId = (expObj instanceof Number) ? ((Number) expObj).longValue() : 0;
            String contenu    = (String) msg.get("contenu");
            Object luObj      = msg.get("lu");
            boolean estMoi    = (expediteurId == idpers);
            int luValue       = (luObj instanceof Number) ? ((Number) luObj).intValue() : 0;

            LinearLayout wrapper = new LinearLayout(this);
            wrapper.setOrientation(LinearLayout.VERTICAL);
            LinearLayout.LayoutParams wrapParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            wrapParams.setMargins(0, 0, 0, 16);
            wrapper.setLayoutParams(wrapParams);
            wrapper.setGravity(estMoi ? Gravity.END : Gravity.START);

            CardView card = new CardView(this);
            card.setRadius(24f);
            card.setCardBackgroundColor(estMoi ? Color.parseColor("#DCF8C6") : Color.WHITE);
            
            LinearLayout bubbleLayout = new LinearLayout(this);
            bubbleLayout.setOrientation(LinearLayout.VERTICAL);
            bubbleLayout.setPadding(28, 20, 28, 10);

            TextView tvContenu = new TextView(this);
            tvContenu.setText(contenu);
            tvContenu.setTextColor(Color.BLACK);
            bubbleLayout.addView(tvContenu);

            // Indicateur "Lu" pour mes messages
            if (estMoi) {
                TextView tvLu = new TextView(this);
                tvLu.setText(luValue == 1 ? "✓✓ Lu" : "✓ Envoyé");
                tvLu.setTextSize(9);
                tvLu.setGravity(Gravity.END);
                tvLu.setTextColor(luValue == 1 ? Color.parseColor("#34B7F1") : Color.GRAY);
                bubbleLayout.addView(tvLu);
            }
            
            card.addView(bubbleLayout);
            wrapper.addView(card);
            containerMessages.addView(wrapper);
        }
        scrollView.post(() -> scrollView.fullScroll(ScrollView.FOCUS_DOWN));
    }

    private void envoyerMessage() {
        String texte = etMessage.getText().toString().trim();
        if (texte.isEmpty()) return;
        Map<String, Object> body = new HashMap<>();
        body.put("expediteur", idpers);
        body.put("destinataire", interlocuteur);
        body.put("contenu", texte);
        RetrofitClient.getService().envoyerMessage(body).enqueue(new Callback<Map<String, Object>>() {
            @Override
            public void onResponse(Call<Map<String, Object>> call, Response<Map<String, Object>> response) {
                if (response.isSuccessful()) { etMessage.setText(""); chargerConversation(); }
            }
            @Override
            public void onFailure(Call<Map<String, Object>> call, Throwable t) {}
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        handler.removeCallbacks(refreshRunnable);
    }
}