// com/wassalni/app/StatistiquesActivity.java
package com.wassalni.app;

import android.app.DatePickerDialog;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.wassalni.app.api.RetrofitClient;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class StatistiquesActivity extends AppCompatActivity {

    private Calendar calDebut, calFin;
    private TextView tvDateDebut, tvDateFin, tvFinanceAujourdhui, tvFinancePeriode, tvLivreurMois, tvScoreLivreur;
    private LinearLayout containerLivreurs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_statistiques);

        calFin = Calendar.getInstance();
        calDebut = Calendar.getInstance();
        calDebut.add(Calendar.MONTH, -6);

        tvDateDebut = findViewById(R.id.tvDateDebut);
        tvDateFin = findViewById(R.id.tvDateFin);
        tvFinanceAujourdhui = findViewById(R.id.tvFinanceAujourdhui);
        tvFinancePeriode = findViewById(R.id.tvFinancePeriode);
        tvLivreurMois = findViewById(R.id.tvLivreurMois);
        tvScoreLivreur = findViewById(R.id.tvScoreLivreur);
        containerLivreurs = findViewById(R.id.containerLivreurs);

        updateDateUI();

        findViewById(R.id.btnBack).setOnClickListener(v -> finish());
        findViewById(R.id.btnDateDebut).setOnClickListener(v -> showDatePicker(true));
        findViewById(R.id.btnDateFin).setOnClickListener(v -> showDatePicker(false));
        
        findViewById(R.id.navAccueil).setOnClickListener(v -> finish());

        chargerDonnees();
    }

    private void showDatePicker(boolean isDebut) {
        Calendar cal = isDebut ? calDebut : calFin;
        new DatePickerDialog(this, (view, year, month, dayOfMonth) -> {
            cal.set(year, month, dayOfMonth);
            updateDateUI();
            chargerDonnees();
        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show();
    }

    private void updateDateUI() {
        SimpleDateFormat fmt = new SimpleDateFormat("dd/MM/yyyy", Locale.FRANCE);
        tvDateDebut.setText(fmt.format(calDebut.getTime()));
        tvDateFin.setText(fmt.format(calFin.getTime()));
    }

    private void chargerDonnees() {
        RetrofitClient.getService().getAllLivraisons().enqueue(new Callback<List<Map<String, Object>>>() {
            @Override
            public void onResponse(Call<List<Map<String, Object>>> call, Response<List<Map<String, Object>>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    calculerStats(response.body());
                }
            }
            @Override
            public void onFailure(Call<List<Map<String, Object>>> call, Throwable t) {}
        });
    }

    private void calculerStats(List<Map<String, Object>> livraisons) {
        double totalAujourdhui = 0;
        double totalPeriode = 0;
        
        SimpleDateFormat sdfApi = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
        String today = sdfApi.format(Calendar.getInstance().getTime());
        String debut = sdfApi.format(calDebut.getTime());
        String fin = sdfApi.format(calFin.getTime());

        Map<String, Integer> livraisonsParLivreur = new HashMap<>();
        Map<String, double[]> detailsPerformance = new HashMap<>(); // [Total, Livrees, EnCours, Echec, Montant]

        for (Map<String, Object> liv : livraisons) {
            String dateLiv = getString(liv, "dateliv");
            String etat = getString(liv, "etatliv");
            double montant = getMontant(liv);

            // 1. Calcul Financier
            if ("Livrée".equalsIgnoreCase(etat)) {
                if (dateLiv.equals(today)) totalAujourdhui += montant;
                if (dateLiv.compareTo(debut) >= 0 && dateLiv.compareTo(fin) <= 0) {
                    totalPeriode += montant;
                }
            }

            // 2. Performance Livreurs
            String nomLivreur = getNomLivreur(liv);
            if (nomLivreur.isEmpty()) continue;

            if (dateLiv.compareTo(debut) >= 0 && dateLiv.compareTo(fin) <= 0) {
                double[] s = detailsPerformance.getOrDefault(nomLivreur, new double[]{0,0,0,0,0});
                s[0]++; // Total
                if ("Livrée".equalsIgnoreCase(etat)) {
                    s[1]++; // Livrees
                    s[4] += montant; // Montant collecté par ce livreur
                } else if ("En cours".equalsIgnoreCase(etat)) {
                    s[2]++;
                } else if ("Échec".equalsIgnoreCase(etat) || "Non livrée".equalsIgnoreCase(etat)) {
                    s[3]++;
                }
                detailsPerformance.put(nomLivreur, s);
                
                // Pour le livreur du mois (celui qui a le plus de "Livrée")
                if ("Livrée".equalsIgnoreCase(etat)) {
                    livraisonsParLivreur.put(nomLivreur, livraisonsParLivreur.getOrDefault(nomLivreur, 0) + 1);
                }
            }
        }

        // Affichage Finances
        tvFinanceAujourdhui.setText(String.format(Locale.FRANCE, "%,.3f DT", totalAujourdhui));
        tvFinancePeriode.setText(String.format(Locale.FRANCE, "%,.3f DT", totalPeriode));

        // Détermination Livreur du Mois
        String bestLivreur = "Aucun";
        int maxLiv = 0;
        for (Map.Entry<String, Integer> entry : livraisonsParLivreur.entrySet()) {
            if (entry.getValue() > maxLiv) {
                maxLiv = entry.getValue();
                bestLivreur = entry.getKey();
            }
        }
        tvLivreurMois.setText(bestLivreur);
        tvScoreLivreur.setText(maxLiv + " livraisons");

        // Affichage Liste Performance
        afficherListeLivreurs(detailsPerformance);
    }

    private void afficherListeLivreurs(Map<String, double[]> stats) {
        containerLivreurs.removeAllViews();
        List<String> sortedNames = new ArrayList<>(stats.keySet());
        Collections.sort(sortedNames);

        for (String nom : sortedNames) {
            double[] s = stats.get(nom);
            ajouterItemLivreur(nom, s);
        }
    }

    private void ajouterItemLivreur(String nom, double[] s) {
        int total = (int)s[0], livrees = (int)s[1], enCours = (int)s[2], echec = (int)s[3];
        double montant = s[4];
        int pct = (total > 0) ? (livrees * 100 / total) : 0;

        LinearLayout item = new LinearLayout(this);
        item.setOrientation(LinearLayout.VERTICAL);
        item.setPadding(0, 16, 0, 16);

        LinearLayout row1 = new LinearLayout(this);
        TextView tvN = new TextView(this);
        tvN.setText(nom); tvN.setTextColor(Color.BLACK); tvN.setTypeface(null, Typeface.BOLD);
        row1.addView(tvN, new LinearLayout.LayoutParams(0, -2, 1f));

        TextView tvM = new TextView(this);
        tvM.setText(String.format(Locale.FRANCE, "%,.3f DT", montant));
        tvM.setTextColor(Color.parseColor("#2E7D32")); tvM.setTypeface(null, Typeface.BOLD);
        row1.addView(tvM);
        item.addView(row1);

        ProgressBar pb = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        pb.setMax(100); pb.setProgress(pct);
        pb.setProgressDrawable(ContextCompat.getDrawable(this, R.drawable.custom_progress_bar));
        item.addView(pb, new LinearLayout.LayoutParams(-1, 12) {{ setMargins(0, 8, 0, 8); }});

        LinearLayout footer = new LinearLayout(this);
        addBadge(footer, "✓ " + livrees, "#2E7D32");
        addBadge(footer, "✗ " + echec, "#C62828");
        TextView tvP = new TextView(this);
        tvP.setText(pct + "% réussite"); tvP.setTextSize(11); tvP.setGravity(Gravity.END);
        footer.addView(tvP, new LinearLayout.LayoutParams(-1, -2));
        item.addView(footer);

        containerLivreurs.addView(item);
        View line = new View(this);
        line.setBackgroundColor(Color.parseColor("#EEEEEE"));
        containerLivreurs.addView(line, new LinearLayout.LayoutParams(-1, 2));
    }

    private String getNomLivreur(Map<String, Object> liv) {
        String n = getString(liv, "nomLivreur");
        String p = getString(liv, "prenomLivreur");
        if (n.equals("—")) n = getString(liv, "nompers");
        if (p.equals("—")) p = getString(liv, "prenompers");
        
        if (n.equals("—") && liv.get("livreur") instanceof Map) {
            Map<String, Object> lObj = (Map<String, Object>) liv.get("livreur");
            n = getString(lObj, "nompers");
            p = getString(lObj, "prenompers");
        }
        String res = (p + " " + n).replace("—", "").trim();
        if (res.isEmpty()) {
            Object id = liv.get("livreur");
            if (id instanceof Number) return "Livreur #" + ((Number)id).intValue();
        }
        return res;
    }

    private double getMontant(Map<String, Object> liv) {
        Object m = liv.get("montantTotal");
        if (m == null) m = liv.get("montant_total");
        return (m instanceof Number) ? ((Number) m).doubleValue() : 0;
    }

    private String getString(Map<String, Object> m, String k) {
        Object v = m.get(k);
        return v != null ? v.toString() : "—";
    }

    private void addBadge(LinearLayout c, String t, String col) {
        TextView tv = new TextView(this);
        tv.setText(t); tv.setTextSize(11); tv.setTextColor(Color.parseColor(col));
        tv.setPadding(0, 0, 20, 0);
        c.addView(tv);
    }
}
